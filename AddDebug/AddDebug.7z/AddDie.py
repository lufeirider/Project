from Npp import *  

pos = editor.getSelectionEnd()
editor.insertText(pos,"print_r('11111111');die;")
