<?php 
	$conn=mysql_connect("localhost","root","1234abcd");
	mysql_select_db("sscan");
	
	
	$arr = explode('|||',$_POST['value']);
	$url = $arr[0];
	$method = $arr[1];
	$headers = $arr[2];
	$body = $arr[3];
	
	/*
	$url="url";
	$method="method";
	$headers="headers";
	$body="body";
	*/
	print "url===".$url."method====".$method."headers=======".$headers."body=====".$body;
	
	print_r($_POST['is']);
	if($_POST['is']==1)
	{
		mysql_query("insert into task(method,url,headers,body) values('$method','$url','$headers','$body')");
	}
	
?>