<?php
/*
    function doPost($api,$body){
        $header = array(
            'Content-Type: application/json',
        );
        $options = array(
                CURLOPT_URL =>$this->sqlmapapi.$api ,
                CURLOPT_POST=>true,
                CURLOPT_RETURNTRANSFER=>true,
                CURLOPT_POSTFIELDS=>$body,
                CURLOPT_HEADER=>$header,
                CURLOPT_USERAGENT=>'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.57 Safari/537.17',
        );
        return $this->mycurl($options);
    }
	
	function mycurl($options){
        $c=curl_init();
        curl_setopt_array($c,$options);
        $result=curl_exec($c);
        curl_close($c);
        return $result;
    }

	$str = base64_decode("aHR0cDovL2FkbWluLmNob3VtZWkuY24vaW5kZXgucGhwL0xvZ2luL2RvU3VibWl0TG9naW58fHxQT1NUfHx8QWNjZXB0OiB0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS93ZWJwLCovKjtxPTAuOA0KT3JpZ2luOiBodHRwOi8vYWRtaW4uY2hvdW1laS5jbg0KVXBncmFkZS1JbnNlY3VyZS1SZXF1ZXN0czogMQ0KVXNlci1BZ2VudDogTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgNi4xOyBXT1c2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzQ3LjAuMjUyNi4xMDYgU2FmYXJpLzUzNy4zNg0KQ29udGVudC1UeXBlOiBhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQNClJlZmVyZXI6IGh0dHA6Ly9hZG1pbi5jaG91bWVpLmNuL2luZGV4LnBocC9Mb2dpbi9pbmRleA0KQWNjZXB0LUVuY29kaW5nOiBnemlwLCBkZWZsYXRlDQpBY2NlcHQtTGFuZ3VhZ2U6IHpoLUNOLHpoO3E9MC44DQpDb29raWU6IFBIUFNFU1NJRD1tOTEwOTljbzlnNTBjdXZhdmo4MWo4dW5lMA0KfHx8YWN0PXNpZ25pbiZwYXNzd29yZD14eHgmdXNlcm5hbWU9eHh4Jg==");
	$arr = explode('|||',$str);
	print_r($arr);
	
	echo json_encode($arr[2]);
*/

	$conn=mysql_connect("localhost","root","1234abcd");
	mysql_select_db("sscan");
	//print_r($_POST['value']);
	
	
/*
	$b=$_POST['value'];
	print_r($_POST['is']);
	if($_POST['is']==1)
	{
		mysql_query("insert into test5(id,test5) values('2','$b')");
	}
	
	*/
	$result=mysql_query("select * from task where id=65");
	$row=mysql_fetch_row($result);
	$url = "\"url\": \"".$row[2]."\"";
	$body = "\"data\": \"".$row[5]."\"";
	$j_body = "{".$url.",".$body.",".$row[4]."\"}";
	//print $j_body;
	
	
	//$j_body = '{"url": "http://192.168.1.100/guest/login.php","data": "username=1111&password=2222&do=提交"}';
	//print $j_body;
	
	/*
	function doPost($api,$body){
		print $body;
        $header = array(
            'Content-Type: application/json',
        );
        $options = array(
                CURLOPT_URL =>$api ,
                CURLOPT_POST=>true,
                CURLOPT_RETURNTRANSFER=>false,
                CURLOPT_POSTFIELDS=>$body,
                CURLOPT_HEADER=>$header,
                CURLOPT_USERAGENT=>'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.57 Safari/537.17',
				
        );
        return mycurl($options);
    }
	
	function mycurl($options){
        $c=curl_init();
        curl_setopt_array($c,$options);
        $result=curl_exec($c);
        curl_close($c);
        return $result;
    }
	
	//http://192.168.1.128:8775/task/new
	doPost("http://127.0.0.1:8775/scan/292635a257bc5c2b/start",$j_body);
	*/
	
	
	function doPost($url,$body)
	{
		print_r($body);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'http://192.168.1.128:8775/scan/087fbba108d0e4e8/start');
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS,$body);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json','Content-Length: ' . strlen($body)));
		$ret = curl_exec($ch);
		curl_close($ch);
		print_r($ret);
	}
	
	function doGet($url)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json','Content-Length: ' . strlen($body)));
		$ret = curl_exec($ch);
		curl_close($ch);
		return $ret;
	}
	
	function getTaskId($sqlmapai)
	{
		$ret = doGet($sqlmapai."task/new");
		print_r($ret);
		$arrRet = json_decode($jsonRet);
		print_r($arrRet);
		return $arrRet->taskid;
	}
	
	print_r(doPost("http://192.168.1.128:8775/",$j_body));
	
?>