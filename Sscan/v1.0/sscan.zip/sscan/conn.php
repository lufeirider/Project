<?php
	$conn=mysql_connect("localhost","root","1234abcd");
	mysql_select_db("sscan");
?>