req_server = "http://127.0.0.1/sscan/api.php" //发送抓取的数据到服务器,服务器为Redis的http接口
a={}
g_existUrl = {};
/*
抓取POST请求体
Chrome POST请求和header 分为两步，先POST包，然后header，所以只能把所有POST包放到一个全局对象内，等抓取到header，通过requestId合成到一起
*/
chrome.webRequest.onBeforeRequest.addListener ( 
	function(details) {  
			if(details.url.indexOf(req_server) != -1){//过滤插件提交的流量
					return
			}
			if(details["method"] =="POST" && (details["type"] == "main_frame" || details["type"] == "sub_frame" || details["type"] == "xmlhttprequest" || details["type"] == "object")){
					a[details['requestId']] = details["requestBody"].formData  //放到全局对象中

			}
	}, 
	{urls:["<all_urls>"]},
	["requestBody"]
);  

/*抓取header头*/
chrome.webRequest.onSendHeaders.addListener (  
	function(details) {
		//过滤插件提交的流量
		if(details.url.indexOf(req_server) != -1){
				//console.log('pass')
				return
		}
		b={}
		if(details["type"] == "main_frame" || details["type"] == "sub_frame" || details["type"] == "xmlhttprequest" || details["type"] == "object"){
			url = details['url'];
			if(url.indexOf('?')>=0)
			{
				url = url.substring(0,url.indexOf('?'));
			}
			
			if(g_existUrl.hasOwnProperty(url))
			{
				return;
			}
			g_existUrl[url] = 1;
			
			console.log(url);

			b["requestBody"] = ''
			if(details["method"] =="POST"){
				for (i in a[details['requestId']]){
					b["requestBody"] += i + '=' + a[details['requestId']][i][0] + '&'; //构造POST请求字符串
				}
				b["requestBody"]=b["requestBody"].substring(0,b["requestBody"].length-1)
				delete a[details['requestId']]
			}
			else{
				//console.log(details['url']);
				if(details['url'].indexOf("?") == -1){
					return
				}
			}
			headers = ''
			for(i=0;i<details['requestHeaders'].length;i++){
				if(details['requestHeaders'][i].name=="Cookie")
				{
					b["cookie"] = details['requestHeaders'][i].value
				}
				if(i!=details['requestHeaders'].length-1){
					headers += "\""+details['requestHeaders'][i].name+"\": "+"\""+details['requestHeaders'][i].value+"\","; //构造header头
				}else{
					headers += "\""+details['requestHeaders'][i].name+"\": "+"\""+details['requestHeaders'][i].value+"\""; //构造header头
				}
			}
			b["requestHeaders"] = headers
			b["url"] = details.url
			b["method"] = details["method"]
			
			var xhr = new XMLHttpRequest();
			xhr.open("POST", req_server, true); 
			xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			//xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
			xhr.send("is=1&"+"value="+encodeURIComponent(b.url+"|||"+b.method+"|||"+b.requestHeaders+"|||"+b.requestBody+"|||"+b.cookie)) //数据内容，躲避坑爹PY的字符转义所以用了Base64，"|||"分割数据内容，分别为请求url、请求方式、请求头、请求体
			//console.log("is=1&"+"value="+encodeURIComponent(b.url+"|||"+b.method+"|||"+b.requestHeaders+"|||"+b.requestBody));
			//console.log("is=1&"+"value="+b.url+"|||"+b.method+"|||"+b.requestHeaders+"|||"+b.requestBody+"|||"+b.cookie);
			xhr.onloadend = function () {
				console.log(xhr.responseText)
				//console.log("sended") //提交后的回调
			};   						
		}
	},  
	{urls:["<all_urls>"]},
	["requestHeaders"]
);  