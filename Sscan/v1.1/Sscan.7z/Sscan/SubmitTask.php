<?php
include 'config/conn.php';
include 'class/sqlmapapi.class.php';

	$sqlmapapi = new sqlmapapi;
	$sql="select * from task;";
	$re=mysql_query($sql);
	while($row=mysql_fetch_array($re))
	{
		if($row['status']==0)
		{
			$url = "\"url\": \"".$row['url']."\"";
			$body = "\"data\": \"".$row['body']."\"";
			$j_body = "{".$url.",".$body.",".$row['headers']."}";
			print_r($j_body);
			$taskid = $sqlmapapi->getTaskId($sqlmapapi->sqlmapai);
			echo $sqlmapapi->submitTask($sqlmapapi->sqlmapai."scan/".$taskid."/start",$j_body);
			
			$updateSql="update task set status=1,taskid='$taskid' where id={$row['id']};";
			mysql_query($updateSql);
		}
	}
	
header("Location: list.php");
?>