-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- 主机: 127.0.0.1:3306
-- 生成日期: 2016 年 01 月 16 日 08:06
-- 服务器版本: 5.1.28
-- PHP 版本: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `sscan`
--

-- --------------------------------------------------------

--
-- 表的结构 `task`
--

CREATE TABLE IF NOT EXISTS `task` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `taskid` varchar(20) NOT NULL,
  `url` varchar(255) NOT NULL,
  `method` varchar(20) NOT NULL,
  `headers` varchar(500) NOT NULL,
  `body` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `vul` tinyint(1) NOT NULL,
  `detail` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=67 ;

--
-- 导出表中的数据 `task`
--

INSERT INTO `task` (`id`, `taskid`, `url`, `method`, `headers`, `body`, `status`, `vul`, `detail`) VALUES
(60, '3dab01ade418e64b', 'http://192.168.1.100/guest/login.php', 'POST', '"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8","Origin": "http://192.168.1.100","Upgrade-Insecure-Requests": "1","User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.', 'action=login&do=ï¿½ï¿½ Â½ &password=333333333&username=2222222', 2, 1, ''),
(61, 'dfc60cdc07a6c751', 'http://192.168.1.100/blog/index/user/runLogin', 'POST', '"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8","Origin": "http://192.168.1.100","Upgrade-Insecure-Requests": "1","User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.', 'password=222222222&username=11111111', 2, 0, ''),
(62, '795beb267799a2c4', 'http://192.168.1.100/guest/login.php', 'POST', '"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8","Origin": "http://192.168.1.100","Upgrade-Insecure-Requests": "1","User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.', 'action=login&do=ï¿½ï¿½ Â½ &password=lufei&username=admin', 2, 1, ''),
(66, 'cb3286231d41723c', 'http://192.168.1.100/guest/edit.php?id=345', 'GET', '"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8","Upgrade-Insecure-Requests": "1","User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36","Accept-Encoding": "gzip, deflate, sdch","Accept-Language": "zh-CN,zh;q=0.8","Cookie": "PHPSESSID=f8ef80d4f53c3357a0ff6837dcac2689"', '', 2, 1, ''),
(65, 'c050cfeb5b799463', 'http://192.168.1.100/guest/edit.php?id=345', 'GET', '"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8","Upgrade-Insecure-Requests": "1","User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36","Referer": "http://192.168.1.100/guest/index.php","Accept-Encoding": "gzip, deflate, sdch","Accept-Language": "zh-CN,zh;q=0.8","Cookie": "PHPSESSID=f8ef80d4f53c3357a0ff6837dcac2689"', '', 1, 0, '');
