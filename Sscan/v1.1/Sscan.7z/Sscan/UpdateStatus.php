<?php
include 'config/conn.php';
include 'class/sqlmapapi.class.php';

$sqlmapapi = new sqlmapapi;
$sql="select * from task;";
$re=mysql_query($sql);
while($row=mysql_fetch_array($re))
{
	if($row['status']==1)
	{
		print_r($sqlmapapi->isStop($sqlmapapi->sqlmapai,$row['taskid']));
		if($sqlmapapi->isStop($sqlmapapi->sqlmapai,$row['taskid'])=="terminated")
		{
			
			$updateSql="update task set status=2 where id={$row['id']};";
			mysql_query($updateSql);
		}
	}
}
	
header("Location: list.php");
?>