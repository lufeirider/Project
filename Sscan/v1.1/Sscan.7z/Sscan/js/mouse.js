 function show(tdobject)
 {
	var td = $(tdobject);
	//�޸���ʽ
	td.attr("style", "word-break:break-all; word-wrap:break-all;text-overflow: normal;white-space: normal; ");
	var text = td.text();
	//�޸�����
	//td.html("<textarea cols='2'>"+text+"</textarea>");
	//alert(text);
 }
 
 function hide(tdobject)
 {
	var td = $(tdobject);
	//�޸���ʽ
	td.attr("style", "word-break:break-all; word-wrap:break-all;text-overflow: ellipsis;white-space: nowrap; ");
	var text = td.text();
	//�޸�����
	//td.html("<textarea cols='2'>"+text+"</textarea>");
	//alert(text);
 }