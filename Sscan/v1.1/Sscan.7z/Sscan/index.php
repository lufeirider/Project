<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>控制台</title>
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.min.css" rel="stylesheet">
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="css/style.css">
	</head>

	<body>
		<!--头部导航开始-->
		<?php include 'header.html';?>
		<!--头部导航结束-->
		<!--左边导航开始-->
		<?php include 'sidebar.html';?>
		<!--左边导航结束-->
		<div id="content">
			<!--仪表盘开始-->
			<div class="container-fluid">
				<div class="row-fluid">
					<div class="span12">
						<div class="container-fluid">
							<div class="row">
								<div >
									<h1 class="page-header">
										仪表盘
									</h1>
									<div class="row placeholders">
										<div class="col-md-offset-1 col-xs-6 col-sm-3 placeholder">
											<div class="container-fluid">
												<div class="row-fluid">
													<div class="span12">
														<div class="hero-unit">
															<h1>
																所有数据包
															</h1>
															<p>
																查看所有的数据包,没有进行任何的过滤。展示所有的数据包在表格当中。
															</p>
															<p>
																<a class="btn btn-primary btn-large" href="list.php">参看更多 »</a>
															</p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="col-md-offset-3 col-xs-6 col-sm-3 placeholder">
											<div class="container-fluid">
												<div class="row-fluid">
													<div class="span12">
														<div class="hero-unit">
															<h1>
																漏洞数据包
															</h1>
															<p>
																查看有漏洞的数据包,对没有漏洞的数据包进行任何的过滤。展示的数据包在表格当中。
															</p>
															<p>
																<a class="btn btn-primary btn-large" href="list.php?vul=vul">参看更多 »</a>
															</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--仪表盘结束-->
			<!--详细描述开始-->
			<?php include 'detail.html';?>
			<!--详细描述结束-->
		</div>
		
	</body>
</html>