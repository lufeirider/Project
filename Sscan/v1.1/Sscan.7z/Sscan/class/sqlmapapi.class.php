<?php 
class sqlmapapi{
	public $sqlmapai='http://192.168.50.130:8775/';
	function doPost($url,$body)
	{
		//print_r($url);
		//print_r($body);
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,$body);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json','Content-Length: ' . strlen($body)));
		$ret = curl_exec($ch);
		curl_close($ch);
		print_r($ret);
	}
	
	
	function doGet($url)
	{
		$body = "";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json','Content-Length: ' . strlen($body)));
		$ret = curl_exec($ch);
		curl_close($ch);
		return $ret;
	}
	
	function getTaskId($sqlmapai)
	{
		$jsonRet = $this->doGet($sqlmapai."task/new");
		$arrRet = json_decode($jsonRet);
		return $arrRet->taskid;
	}
	
	function submitTask($url,$body)
	{
		$this->doPost($url,$body);
	}
	
	function isStop($sqlmapai,$taskid)
	{
		$jsonRet = $this->doGet($sqlmapai."scan/".$taskid."/status");
		$arrRet = json_decode($jsonRet);
		return $arrRet->status;
	}
	
	function isVul($sqlmapai,$taskid)
	{
		$jsonRet = $this->doGet($sqlmapai."scan/".$taskid."/data");
		$arrRet = json_decode($jsonRet);
		return $arrRet->data;
	}
	
	
}

?>