<?php
include 'conn.php';
$sql = "CREATE database sscan";
mysql_query($sql,$conn);

mysql_select_db("sscan");


$sql_array=preg_split("/;[\r\n]+/", file_get_contents('./task.sql'));  
foreach ($sql_array as $k => $v) {  
	mysql_query($v,$conn);  
	echo mysql_error().'<br>';  
}  
?>