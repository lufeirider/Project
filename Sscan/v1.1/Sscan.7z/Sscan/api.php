<?php 
include 'config/conn.php';
include 'class/sqlmapapi.class.php';

$arr = explode('|||',$_POST['value']);
$url = $arr[0];
$method = $arr[1];
$headers = $arr[2];
$body = $arr[3];
$cookie = $arr[4];

$headers = $cookie;
if(isset($header))
{
	$header = "";
}


$sqlmapapi = new sqlmapapi;
/*
$url="url";
$method="method";
$headers="headers";
$body="body";
*/

//print_r($_POST['is']);
if($_POST['is']==1)
{
	if(empty($body))
	{
		$j_body = "{\"url\":\"".$url."\",\"cookie\":\"".$headers."\"}";
	}else
	{
		$j_body = "{\"url\":\"".$url."\",\"data\":\"".$body."\",\"cookie\":\"".$headers."\"}";
	}
	
	//print_r($j_body);die;
	
	$taskid = $sqlmapapi->getTaskId($sqlmapapi->sqlmapai);print_r($taskid);
	print_r($j_body);
	$sqlmapapi->submitTask($sqlmapapi->sqlmapai."scan/".$taskid."/start",$j_body);
	
	mysql_query("insert into task(method,url,headers,body,taskid,status) values('$method','$url','$headers','$body','$taskid','1')");
}
	
?>