<?php
include 'config/conn.php';
include 'class/sqlmapapi.class.php';
$sqlmapapi = new sqlmapapi;
$pageSize=10;


if(!empty($_GET['vul']) && $_GET['vul']=='vul'){
	$result = mysql_query("select count(*) from task where vul=1");
}else{
	$result = mysql_query("select count(*) from task");
}
//$result = mysql_query("select count(*) from task");
$row = mysql_fetch_row($result);
$sum = $row[0];
$pageCount = ceil($sum/$pageSize);
$currPage = empty($_GET["page"])?1:$_GET["page"];
if($currPage > $pageCount)
{
	$currPage = 1;
}

$vulResult = mysql_query("select count(*) from task where vul=1");
$vulRow = mysql_fetch_row($vulResult);
$vulSum = $vulRow[0];
$vulPageCount = ceil($vulSum/$pageSize);
$vulCurrPage = empty($_GET["page"])?1:$_GET["page"];
if($vulCurrPage > $vulPageCount)
{
	$vulCurrPage=1;
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>数据详细</title>
		
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.min.css" rel="stylesheet">
		
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/bootstrap-paginator.min.js"></script>
		
		<script src="js/mouse.js"></script>
		<link rel="stylesheet" href="css/style.css">
	</head>

	<body>
		<!--头部导航开始-->
		<?php include 'header.html';?>
		<!--头部导航结束-->
		<!--左边导航开始-->
		<?php include 'sidebar.html';?>
		<!--左边导航结束-->
		<div id="content">
			<!--表格详情页面开始-->
				<div class="container-fluid" id="detail_table">
					<div class="row-fluid">
						<div class="span12">
							<table class="table">
								<thead>
									<tr>
										<th style="width:5%;">
											ID
										</th>
										<th style="width:15%;">
											TASKID
										</th>
										<th style="width:40%;">
											URL
										</th>
										<th style="width:35%;">
											BODY
										</th>
										<th style="width:5%;">
											状态
										</th>
									</tr>
								</thead>
								<tbody>
									<?php 
										$sql="select * from task limit ".($currPage-1)*$pageSize.",".$pageSize;
										
										$re = mysql_query($sql);
										while($row=mysql_fetch_array($re))
										{
											if($row['status']=='1')
											{
												if($sqlmapapi->isVul($sqlmapapi->sqlmapai,$row['taskid']))
												{
													$updateSql="update task set vul=1,status=2 where id='{$row['id']}'";
													mysql_query($updateSql);
												}
											}

										}
										
										if(!empty($_GET['vul']) && $_GET['vul']=='vul')
										{
											$sql="select * from task";
											$re = mysql_query($sql);
											while($row=mysql_fetch_array($re))
											{
												if($row['vul'] == 1)
													echo '<tr class="danger"><td>'.$row['id'].'</td><td>'.$row['taskid'].'</td><td onMouseOver="show(this);" onmouseout="hide(this);">'.$row['url'].'</td><td onMouseOver="show(this);" onmouseout="hide(this);">'.$row['body'].'</td><td>'.$row['status'].'</td></tr>';
											}
										}else{
											$re = mysql_query($sql);
											while($row=mysql_fetch_array($re))
											{
												if($row['vul'] == 1)
													echo '<tr class="danger"><td>'.$row['id'].'</td><td>'.$row['taskid'].'</td><td onMouseOver="show(this);" onmouseout="hide(this);">'.$row['url'].'</td><td onMouseOver="show(this);" onmouseout="hide(this);">'.$row['body'].'</td><td>'.$row['status'].'</td></tr>';
												else
													echo '<tr><td>'.$row['id'].'</td><td>'.$row['taskid'].'</td><td onMouseOver="show(this);" onmouseout="hide(this);">'.$row['url'].'</td><td onMouseOver="show(this);" onmouseout="hide(this);">'.$row['body'].'</td><td>'.$row['status'].'</td></tr>';
											}
										}

									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			<!--表格详情页面结束-->
			<!--分页-->
				<center>
					<ul class="pagination"></ul>
				</center>
			<!--分页结束-->
		</div>
	</body>
	
	<script type='text/javascript'>
        var options = {
            currentPage: <?php echo $currPage;?>,
            totalPages: <?php echo $pageCount;?>,
            pageUrl: function(type, page, current){
                return "?page="+page;

            }
        }
        $('.pagination').bootstrapPaginator(options);
	</script>
</html>