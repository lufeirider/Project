<?php
include 'config/conn.php';
include 'class/sqlmapapi.class.php';

	$sqlmapapi = new sqlmapapi;
	$sql="select * from task;";
	$re=mysql_query($sql);
	while($row=mysql_fetch_array($re))
	{
		if($row['status']==1)
		{
			if($sqlmapapi->isVul($sqlmapapi->sqlmapai,$row['taskid']))
			{
				$updateSql="update task set vul=1 where id={$row['id']};";
				mysql_query($updateSql);
			}
		}
	}
header("Location: list.php");
?>