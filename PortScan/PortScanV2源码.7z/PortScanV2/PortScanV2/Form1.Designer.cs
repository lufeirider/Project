﻿namespace PortScanV2
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.MainPanel = new System.Windows.Forms.Panel();
            this.IpTextBox = new System.Windows.Forms.TextBox();
            this.ScanButton = new System.Windows.Forms.Button();
            this.IpLabel = new System.Windows.Forms.Label();
            this.PortNumLabel = new System.Windows.Forms.Label();
            this.MaxSocketNumTextBox = new System.Windows.Forms.TextBox();
            this.ResultTextBox = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.ResultToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.RateToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.ToalTimeToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.MainPanel.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainPanel
            // 
            this.MainPanel.Controls.Add(this.MaxSocketNumTextBox);
            this.MainPanel.Controls.Add(this.PortNumLabel);
            this.MainPanel.Controls.Add(this.IpLabel);
            this.MainPanel.Controls.Add(this.ScanButton);
            this.MainPanel.Controls.Add(this.IpTextBox);
            this.MainPanel.Location = new System.Drawing.Point(13, 0);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(591, 51);
            this.MainPanel.TabIndex = 0;
            // 
            // IpTextBox
            // 
            this.IpTextBox.Location = new System.Drawing.Point(33, 14);
            this.IpTextBox.Name = "IpTextBox";
            this.IpTextBox.Size = new System.Drawing.Size(100, 21);
            this.IpTextBox.TabIndex = 0;
            // 
            // ScanButton
            // 
            this.ScanButton.Location = new System.Drawing.Point(491, 15);
            this.ScanButton.Name = "ScanButton";
            this.ScanButton.Size = new System.Drawing.Size(100, 21);
            this.ScanButton.TabIndex = 1;
            this.ScanButton.Text = "Scan";
            this.ScanButton.UseVisualStyleBackColor = true;
            this.ScanButton.Click += new System.EventHandler(this.ScanButton_Click);
            // 
            // IpLabel
            // 
            this.IpLabel.AutoSize = true;
            this.IpLabel.Location = new System.Drawing.Point(-2, 19);
            this.IpLabel.Name = "IpLabel";
            this.IpLabel.Size = new System.Drawing.Size(29, 12);
            this.IpLabel.TabIndex = 1;
            this.IpLabel.Text = "Ip：";
            // 
            // PortNumLabel
            // 
            this.PortNumLabel.AutoSize = true;
            this.PortNumLabel.Location = new System.Drawing.Point(234, 19);
            this.PortNumLabel.Name = "PortNumLabel";
            this.PortNumLabel.Size = new System.Drawing.Size(65, 12);
            this.PortNumLabel.TabIndex = 2;
            this.PortNumLabel.Text = "并发数量：";
            // 
            // MaxSocketNumTextBox
            // 
            this.MaxSocketNumTextBox.Location = new System.Drawing.Point(305, 14);
            this.MaxSocketNumTextBox.Name = "MaxSocketNumTextBox";
            this.MaxSocketNumTextBox.Size = new System.Drawing.Size(100, 21);
            this.MaxSocketNumTextBox.TabIndex = 3;
            this.MaxSocketNumTextBox.Text = "10000";
            // 
            // ResultTextBox
            // 
            this.ResultTextBox.Location = new System.Drawing.Point(13, 58);
            this.ResultTextBox.Multiline = true;
            this.ResultTextBox.Name = "ResultTextBox";
            this.ResultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ResultTextBox.Size = new System.Drawing.Size(591, 242);
            this.ResultTextBox.TabIndex = 1;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ResultToolStripStatusLabel,
            this.RateToolStripStatusLabel,
            this.ToalTimeToolStripStatusLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 303);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(616, 26);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // ResultToolStripStatusLabel
            // 
            this.ResultToolStripStatusLabel.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.ResultToolStripStatusLabel.Name = "ResultToolStripStatusLabel";
            this.ResultToolStripStatusLabel.Size = new System.Drawing.Size(95, 21);
            this.ResultToolStripStatusLabel.Text = "扫描结果：0 个";
            // 
            // RateToolStripStatusLabel
            // 
            this.RateToolStripStatusLabel.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.RateToolStripStatusLabel.Name = "RateToolStripStatusLabel";
            this.RateToolStripStatusLabel.Size = new System.Drawing.Size(70, 21);
            this.RateToolStripStatusLabel.Text = "进度：0 %";
            // 
            // ToalTimeToolStripStatusLabel
            // 
            this.ToalTimeToolStripStatusLabel.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.ToalTimeToolStripStatusLabel.Name = "ToalTimeToolStripStatusLabel";
            this.ToalTimeToolStripStatusLabel.Size = new System.Drawing.Size(120, 21);
            this.ToalTimeToolStripStatusLabel.Text = "扫描用时：00:00:00";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 329);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.ResultTextBox);
            this.Controls.Add(this.MainPanel);
            this.Name = "MainForm";
            this.Text = "PortScan";
            this.MainPanel.ResumeLayout(false);
            this.MainPanel.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel MainPanel;
        private System.Windows.Forms.TextBox MaxSocketNumTextBox;
        private System.Windows.Forms.Label PortNumLabel;
        private System.Windows.Forms.Label IpLabel;
        private System.Windows.Forms.Button ScanButton;
        private System.Windows.Forms.TextBox IpTextBox;
        private System.Windows.Forms.TextBox ResultTextBox;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel ResultToolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel RateToolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel ToalTimeToolStripStatusLabel;
    }
}

