// KeyboardRecordExe.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include <windows.h>
#include <tlhelp32.h>

typedef BOOL(*StartHookA)(DWORD dwThreadId);

DWORD GetProcessId(char* Name)
{
	int i = 1000;
	PROCESSENTRY32 pe;
	pe.dwSize = sizeof(PROCESSENTRY32);
	HANDLE Handle = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	Process32First(Handle, &pe);
	int x = strcmp(Name, pe.szExeFile);
	if (x == 0)
	{
		return pe.th32ProcessID;
	}
	while (i > 0)
	{
		Process32Next(Handle, &pe);
		x = strcmp(Name, pe.szExeFile);
		if (x == 0)
		{
			return pe.th32ProcessID;
		}
		i--;
	}
	return 0;
}

DWORD GetThreadId(DWORD dwProcessId)
{
	DWORD dwThreadID = 0;
	THREADENTRY32 te32 = { sizeof(te32) };
	HANDLE hThreadSnap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, dwProcessId);
	if (Thread32First(hThreadSnap, &te32))
	{
		do {
			if (dwProcessId == te32.th32OwnerProcessID)
			{
				dwThreadID = te32.th32ThreadID;
				break;
			}
		} while (Thread32Next(hThreadSnap, &te32));
	}

	return dwThreadID;
}

int main()
{
	DWORD dwProcessId = GetProcessId("notepad++.exe");
	DWORD dwThreadId = GetThreadId(dwProcessId);

	StartHookA StartHook = (StartHookA)GetProcAddress(LoadLibrary("KeyboardRecordDll.dll"), "StartHook");

	StartHook(dwThreadId);

	while (TRUE)
	{
		Sleep(100000);
	}
    return 0;
}

