url = window.location.href; 
console.log(url);
var index = url.indexOf('?');
if (index > -1)
{
	result = url.substring(index + 1);
	console.log(result);
	waf = result.substring(0,result.indexOf("CDN"));
	cdn = result.substring(result.indexOf("CDN"),result.length);
	console.log(waf);
	console.log(cdn);
	document.getElementById("p1").innerHTML = waf + "<br/>" + cdn;
}