//console.log("background");

var existDomain = new Array();
chrome.tabs.onUpdated.addListener(function(tabId , info) {
    if (info.status == "loading") {						//当打开一个新的网页时候，就进行处理
		
		chrome.tabs.getSelected(null, function(tab){
			////console.log(tab.url);
            var url = tab.url;
			
			re = /htt.*?\/\/.*?\//i; 
			http = re.exec(url); 
			
			if((http!=null) && (http[0].indexOf("http")>=0))			//判断打开的是不是正常网页，而不是浏览器自带的域
			{
				//console.log(http[0]);
				//console.log(existDomain.hasOwnProperty(http));	//判断是不是已经检测过该域名
				if(!existDomain.hasOwnProperty(http))
				{
					GetHttp(http[0],tabId);
				}
				else
				{
					
					if(existDomain[http[0]] != "NULL")
					{
						re = /WAF:(.*?)\W/i; 
						waf = re.exec(existDomain[http[0]]); 
						//console.log(waf[1]);
						
						re = /CDN:(.*)/i; 
						cdn = re.exec(existDomain[http[0]]); 
						//console.log(cdn[1]);

						if((waf[1]!="NULL") && (cdn[1]!="NULL"))
						{
							chrome.browserAction.setBadgeText({text:"3", tabId:tabId});
							chrome.browserAction.setTitle({title:existDomain[http[0]], tabId:tabId});
						}else if(waf[1]!="NULL"){
							chrome.browserAction.setBadgeText({text:"2", tabId:tabId});
							chrome.browserAction.setTitle({title:existDomain[http[0]], tabId:tabId});
						}else if(cdn[1]!="NULL"){
							chrome.browserAction.setBadgeText({text:"1", tabId:tabId});
							chrome.browserAction.setTitle({title:existDomain[http[0]], tabId:tabId});
						}
					}
					
					//console.log(existDomain[http[0]]);
				}
			}
		});
		
    }
});

//使用api获取数据
function GetHttp(url,tabId){
	http = url;
	url = "http://www.lufe1.cn/Probe/ProbeApi.php?url=" + url;
	var xhr = new XMLHttpRequest();
	xhr.open("GET", url, true);
	xhr.onreadystatechange = function() {
	  if ((xhr.readyState == 4) && (xhr.status == 200) ) {
		existDomain[http] = xhr.responseText;
		if(xhr.responseText != "NULL")
		{
			
			re = /WAF:(.*?)\W/i; 
			waf = re.exec(xhr.responseText); 
			//console.log(waf[1]);
			
			re = /CDN:(.*)/i; 
			cdn = re.exec(xhr.responseText); 
			//console.log(cdn[1]);

			if((waf[1]!="NULL") && (cdn[1]!="NULL"))
			{
				chrome.browserAction.setBadgeText({text:"3", tabId:tabId});
				chrome.browserAction.setTitle({title:xhr.responseText, tabId:tabId});
			}else if(waf[1]!="NULL"){
				chrome.browserAction.setBadgeText({text:"2", tabId:tabId});
				chrome.browserAction.setTitle({title:xhr.responseText, tabId:tabId});
			}else if(cdn[1]!="NULL"){
				chrome.browserAction.setBadgeText({text:"1", tabId:tabId});
				chrome.browserAction.setTitle({title:xhr.responseText, tabId:tabId});
			}

		}
		//console.log(xhr.responseText);
	  }
	}
	xhr.send();
};



//当点击browser图标的时候，代码处理
chrome.browserAction.onClicked.addListener(function(tab) {
	chrome.browserAction.getTitle({"tabId":tab.id}, function(result){
		
		chrome.browserAction.setPopup({ tabId: tab.id, popup: "popup.html?"+result});
	});
});

