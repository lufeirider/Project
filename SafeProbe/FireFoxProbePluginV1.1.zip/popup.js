// http://ping.chinaz.com/www.hkctshotels.com
// http://viewdns.info/iphistory/?domain=www.hkctshotels.com
// http://toolbar.netcraft.com/site_report?url=www.hkctshotels.com
// https://dnsdb.io/zh-cn/search?q=www.hkctshotels.com
// https://x.threatbook.cn/domain/www.hkctshotels.com

// http://whoweb.secbug.org/
// http://whatweb.bugscaner.com/look/

//http://www.webscan.cc/
var btn=document.getElementById('btn');
btn.onclick=function(){
	
    browser.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		console.log(tabs);
		// window.http = tabs[0].url;
		console.log(tabs[0].url);
		window.open(tabs[0].url+"/?id=1%20union%20select%201,2,3,4");
		console.log(tabs[0].url+"/?id=1%20union%20select%201,2,3,4");
		browser.tabs.create({
			url:tabs[0].url+"/?id=1%20union%20select%201,2,3,4"
	  });
    });
	
}

var pingbtn=document.getElementById('pingbtn');
pingbtn.onclick=function(){
	
    browser.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		console.log(tabs);
		
		re = /\/\/(.*?)\//i;
		http = re.exec(tabs[0].url);
		console.log(http[1]);
		
		console.log("http://ping.chinaz.com/" + http[1]);
		browser.tabs.create({
			url:"http://ping.chinaz.com/" + http[1]
	  });
    });
	
}

var viewdnsbtn=document.getElementById('viewdnsbtn');
viewdnsbtn.onclick=function(){
	
    browser.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		console.log(tabs);
		
		re = /\/\/(.*?)\//i;
		http = re.exec(tabs[0].url);
		console.log(http[1]);
		
		console.log("http://viewdns.info/iphistory/?domain=" + http[1]);
		browser.tabs.create({
			url:"http://viewdns.info/iphistory/?domain=" + http[1]
	  });
    });
	
}

var netcraftbtn=document.getElementById('netcraftbtn');
netcraftbtn.onclick=function(){
	
    browser.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		console.log(tabs);
		
		re = /\/\/(.*?)\//i;
		http = re.exec(tabs[0].url);
		console.log(http[1]);
		
		console.log("http://toolbar.netcraft.com/site_report?url=" + http[1]);
		browser.tabs.create({
			url:"http://toolbar.netcraft.com/site_report?url=" + http[1]
	  });
    });
}

var dnsdbbtn=document.getElementById('dnsdbbtn');
dnsdbbtn.onclick=function(){
	
    browser.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		console.log(tabs);
		
		re = /\/\/(.*?)\//i;
		http = re.exec(tabs[0].url);
		console.log(http[1]);
		
		console.log("https://dnsdb.io/zh-cn/search?q=" + http[1]);
		browser.tabs.create({
			url:"https://dnsdb.io/zh-cn/search?q=" + http[1]
	  });
    });
	
}

var threatbookbtn=document.getElementById('threatbookbtn');
threatbookbtn.onclick=function(){
	
    browser.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		console.log(tabs);
		
		re = /\/\/(.*?)\//i;
		http = re.exec(tabs[0].url);
		console.log(http[1]);
		
		console.log("https://x.threatbook.cn/domain/" + http[1]);
		browser.tabs.create({
			url:"https://x.threatbook.cn/domain/" + http[1]
	  });
    });
	
}

var secbugbtn=document.getElementById('secbugbtn');
secbugbtn.onclick=function(){
	
    browser.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		console.log(tabs);
		
		re = /\/\/(.*?)\//i;
		http = re.exec(tabs[0].url);
		console.log(http[1]);
		
		console.log("http://whoweb.secbug.org/");
		browser.tabs.create({
			url:"http://whoweb.secbug.org/"
	  });
    });
	
}

var bugscanerbtn=document.getElementById('bugscanerbtn');
bugscanerbtn.onclick=function(){
	
    browser.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		console.log(tabs);
		
		re = /\/\/(.*?)\//i;
		http = re.exec(tabs[0].url);
		console.log(http[1]);
		
		console.log("http://whatweb.bugscaner.com/look/");
		browser.tabs.create({
			url:"http://whatweb.bugscaner.com/look/"
	  });
    });
	
}


var webscanbtn=document.getElementById('webscanbtn');
webscanbtn.onclick=function(){
	
    browser.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		console.log(tabs);
		
		re = /\/\/(.*?)\//i;
		http = re.exec(tabs[0].url);
		console.log(http[1]);
		
		console.log("http://www.webscan.cc/");
		browser.tabs.create({
			url:"http://www.webscan.cc/"
	  });
    });
	
}