console.log("background");

browser.browserAction.onClicked.addListener(function(tab) {
	chrome.browserAction.setPopup({ tabId: tab.id, popup: "popup.html"});
});
