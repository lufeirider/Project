// http://ip.webbaozi.com/

// http://cha.hxsec.com/
// http://so.moonsec.com/index.php
// https://qq.findmima.com/

// https://reg007.com/

// http://somd5.com/
// http://www.objectif-securite.ch/en/ophcrack.php


https://browserleaks.com/webrtc

var ipbtn=document.getElementById('ipbtn');

ipbtn.onclick=function(){
	browser.tabs.create({
		url:"http://ip.webbaozi.com/"
	});
	
}

var hxsecbtn=document.getElementById('hxsecbtn');
hxsecbtn.onclick=function(){
	
	browser.tabs.create({
		url:"http://cha.hxsec.com/"
	});

}

var moonsecbtn=document.getElementById('moonsecbtn');
moonsecbtn.onclick=function(){
	
	browser.tabs.create({
		url:"http://so.moonsec.com/index.php"
	});

}

var findmimabtn=document.getElementById('findmimabtn');
findmimabtn.onclick=function(){
	
	browser.tabs.create({
		url:"https://qq.findmima.com/"
	});

}

var reg007btn=document.getElementById('reg007btn');
reg007btn.onclick=function(){
	
	browser.tabs.create({
		url:"https://reg007.com/"
	});

}

var somd5btn=document.getElementById('somd5btn');
somd5btn.onclick=function(){
	
	browser.tabs.create({
		url:"http://somd5.com/"
	});

}

var securitebtn=document.getElementById('securitebtn');
securitebtn.onclick=function(){
	
	browser.tabs.create({
		url:"http://www.objectif-securite.ch/en/ophcrack.php"
	});

}