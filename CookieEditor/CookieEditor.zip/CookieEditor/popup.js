var URL = '';

function $(id){return document.getElementById(id);}

function inj_cookies(cookies){
	if(!cookies){
		$('status').innerHTML = 'No Cookies Injected.';
		return;
	}
	if (!chrome.cookies) {
	  chrome.cookies = chrome.experimental.cookies;
	}
	
	d = new Date();;
	expired = 365*70; // 70years
	//d.setTime(d.getTime()+expired*24*3600*1000); //millisecond
	//e = d.toGMTString();
	e = d.setTime(d.getTime()/1000+expired*24*3600); //second
	

	domain = URL.split('/')[2];
	//如果popup.html中的domain不等于标签页面的domain,则使用popup.html页面的
	if($('domain').value != domain){
		domain = $('domain').value;
	}
	//url为http(s)://xxx.com
	url = URL.split('/')[0] + '//' + domain;
	
	cc = cookies.split(';');
	for(i in cc){
		c = cc[i].replace(/^\s+|\s+$/g, "");
		if(!c) continue;
		k = c.split('=')[0].replace(/^\s+|\s+$/g, "").replace(' ', '+');
		v = c.split('=')[1].replace(/^\s+|\s+$/g, "").replace(' ', '+');

		chrome.cookies.remove({"url": url, "name": k});
		
		chrome.cookies.set({
			'url': url,
			'name': k,
			'value': v,
			'path': '/',
			'domain': $('domain').value,
			'expirationDate': e,
		});
	};
	$('status').innerHTML = 'OK.';
	
}

//移除cookie
function remove_cookie(cookie) {
  var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
	console.log(url);
  chrome.cookies.remove({"url": url, "name": cookie.name});
}

//清除cookie
function clear_cookie()
{
	chrome.cookies.getAll({
		domain:$('domain').value
	}, function(cookies){
        for(i=0; i<cookies.length;i++) {
			remove_cookie(cookies[i]);
        }
	});
}


function init(){
	$('x').focus();
	$('x').value = localStorage.getItem('cookies');


	//填写popup.html中的domian
	chrome.tabs.getSelected(null,function(tab) {  
		URL = tab.url;
		$('domain').value = URL.split('/')[2];
	});

	//填写popup.html中的cookies
	$('x').addEventListener('blur', function(){
		localStorage.setItem('cookies',$('x').value);
	});
	
	//清除cookie
	$('clear').addEventListener('click', function () {
		clear_cookie();
	});
	
	//监听点击事件，点击则修改cookie
	$('exec_btn').addEventListener('click', function () {
		inj_cookies($('x').value);
	});
	
	
}
document.addEventListener('DOMContentLoaded', init);
