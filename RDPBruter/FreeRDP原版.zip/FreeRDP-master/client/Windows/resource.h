
#define IDI_ICON1                       101
#define IDB_BACKGROUND                  102
#define IDB_MINIMIZE                    103
#define IDB_MINIMIZE_ACT                104
#define IDB_LOCK                        105
#define IDB_LOCK_ACT                    106
#define IDB_UNLOCK                      107
#define IDB_UNLOCK_ACT                  108
#define IDB_CLOSE                       109
#define IDB_CLOSE_ACT                   100
#define IDB_RESTORE                     111
#define IDB_RESTORE_ACT                 112
