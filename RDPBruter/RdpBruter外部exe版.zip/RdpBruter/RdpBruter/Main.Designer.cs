﻿namespace RdpBruter
{
    partial class Form_Main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button_Start = new System.Windows.Forms.Button();
            this.groupBox_Result = new System.Windows.Forms.GroupBox();
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.label_Target = new System.Windows.Forms.Label();
            this.textBox_Target = new System.Windows.Forms.TextBox();
            this.listView_Result = new System.Windows.Forms.ListView();
            this.groupBox_Result.SuspendLayout();
            this.groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_Start
            // 
            this.button_Start.Location = new System.Drawing.Point(514, 19);
            this.button_Start.Name = "button_Start";
            this.button_Start.Size = new System.Drawing.Size(75, 23);
            this.button_Start.TabIndex = 0;
            this.button_Start.Text = "Start";
            this.button_Start.UseVisualStyleBackColor = true;
            this.button_Start.Click += new System.EventHandler(this.button_Start_Click);
            // 
            // groupBox_Result
            // 
            this.groupBox_Result.Controls.Add(this.listView_Result);
            this.groupBox_Result.Location = new System.Drawing.Point(12, 79);
            this.groupBox_Result.Name = "groupBox_Result";
            this.groupBox_Result.Size = new System.Drawing.Size(607, 330);
            this.groupBox_Result.TabIndex = 2;
            this.groupBox_Result.TabStop = false;
            // 
            // groupBox
            // 
            this.groupBox.Controls.Add(this.textBox_Target);
            this.groupBox.Controls.Add(this.label_Target);
            this.groupBox.Controls.Add(this.button_Start);
            this.groupBox.Location = new System.Drawing.Point(18, 13);
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size(595, 60);
            this.groupBox.TabIndex = 3;
            this.groupBox.TabStop = false;
            // 
            // label_Target
            // 
            this.label_Target.AutoSize = true;
            this.label_Target.Location = new System.Drawing.Point(6, 24);
            this.label_Target.Name = "label_Target";
            this.label_Target.Size = new System.Drawing.Size(41, 12);
            this.label_Target.TabIndex = 1;
            this.label_Target.Text = "目标：";
            // 
            // textBox_Target
            // 
            this.textBox_Target.Location = new System.Drawing.Point(53, 21);
            this.textBox_Target.Name = "textBox_Target";
            this.textBox_Target.Size = new System.Drawing.Size(444, 21);
            this.textBox_Target.TabIndex = 2;
            this.textBox_Target.Text = "172.18.30.163";
            // 
            // listView_Result
            // 
            this.listView_Result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView_Result.FullRowSelect = true;
            this.listView_Result.GridLines = true;
            this.listView_Result.Location = new System.Drawing.Point(3, 17);
            this.listView_Result.Name = "listView_Result";
            this.listView_Result.Size = new System.Drawing.Size(601, 310);
            this.listView_Result.TabIndex = 0;
            this.listView_Result.UseCompatibleStateImageBehavior = false;
            this.listView_Result.View = System.Windows.Forms.View.List;
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(631, 421);
            this.Controls.Add(this.groupBox);
            this.Controls.Add(this.groupBox_Result);
            this.Name = "Form_Main";
            this.Text = "Rdp爆破工具";
            this.groupBox_Result.ResumeLayout(false);
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_Start;
        private System.Windows.Forms.GroupBox groupBox_Result;
        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.TextBox textBox_Target;
        private System.Windows.Forms.Label label_Target;
        private System.Windows.Forms.ListView listView_Result;
    }
}

