﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace DirectoryScaner.Tools
{
    class RequestState
    {
        public string statusCode;
        public string length;
        public HttpWebRequest request;
        public RequestState()
        {
            statusCode = "404";
            length = "0";
            request = null;
        }
    }

    class WebHttp
    {
        public static void TimeoutCallback(object state, bool timedOut)
        {
            if (timedOut)
            {
                HttpWebRequest request = state as HttpWebRequest;
                if (request != null)
                {
                    request.Abort();
                }
            }
        }

        ScanInfo myScanInfo = new ScanInfo();
        ManualResetEvent allDone = new ManualResetEvent(false);
        public ScanInfo GetHeaderAsynT(String domain, String path)
        {
            System.GC.Collect();
            RequestState myRequestState = new RequestState();
            
            Uri uri = new Uri(domain + System.Web.HttpUtility.UrlEncode(path));
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            request.AllowAutoRedirect = false;
            request.KeepAlive = false; ;
            myRequestState.request = request;



            IAsyncResult result= request.BeginGetResponse(new AsyncCallback(RespCallback), myRequestState);

            ThreadPool.RegisterWaitForSingleObject(result.AsyncWaitHandle, new WaitOrTimerCallback(TimeoutCallback), request, 1000, true);

            allDone.WaitOne();
            return myScanInfo;
        }

        public void RespCallback(IAsyncResult asynchronousResult)
        {

            RequestState myRequestState = (RequestState)asynchronousResult.AsyncState;
            HttpWebRequest myHttpWebRequest = myRequestState.request;
            try
            {
                HttpWebResponse response = (HttpWebResponse)myHttpWebRequest.GetResponse();
                myScanInfo.length = response.ContentLength.ToString();
                myScanInfo.statusCode = ((int)response.StatusCode).ToString();
                
                response.Close();
            }
            catch (WebException e)
            {
                //防止无法连接出错的情况
                if(e.Response != null)
                {
                    HttpWebResponse response = (HttpWebResponse)e.Response;
                    if (((int)response.StatusCode).ToString().Contains("30"))
                    {
                        myScanInfo.statusCode = ((int)response.StatusCode).ToString();
                    }
                   
                    response.Close();
                }

            }
            myHttpWebRequest.Abort();
            Interlocked.Increment(ref Main.rNum);

            
            allDone.Set();

        }



        public ScanInfo GetHeaderWaf(String domain, String path, String minDealy, String MaxDelay)
        {
            Random random = new Random();
            int delayTIme = random.Next(Convert.ToInt32(minDealy), Convert.ToInt32(MaxDelay));
            ScanInfo testScanInfo = new ScanInfo();

            //if (path.IndexOf('?') >= 0)
            //{
            //    path = System.Web.HttpUtility.UrlEncode(path.Substring(path.IndexOf('?'), path.Length - 1));
            //}

            Uri uri = new Uri(domain  + path);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            request.Timeout = 500;
            Thread.Sleep(delayTIme);
            request.AllowAutoRedirect = false;
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                testScanInfo.statusCode = ((int)response.StatusCode).ToString();
                testScanInfo.length = response.ContentLength.ToString();
                response.Close();
            }
            catch (WebException e)
            {

                if (e.Response != null)
                {
                    HttpWebResponse response = (HttpWebResponse)e.Response;
                    testScanInfo.statusCode = ((int)response.StatusCode).ToString();
                    response.Close();
                }

            }

            return testScanInfo;
        }

        public ScanInfo GetHeaderTest(String domain, String path)
        {
            ScanInfo testScanInfo = new ScanInfo();
            Uri uri = new Uri(domain + path);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            request.AllowAutoRedirect = false;
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                testScanInfo.statusCode = ((int)response.StatusCode).ToString();
                testScanInfo.length = response.ContentLength.ToString();
                response.Close();
            }
            catch (WebException e)
            {
                if (e.Response != null)
                {
                    HttpWebResponse response = (HttpWebResponse)e.Response;
                    testScanInfo.statusCode = ((int)response.StatusCode).ToString();
                    response.Close();
                }

            }

            return testScanInfo;
        }


    }
}
