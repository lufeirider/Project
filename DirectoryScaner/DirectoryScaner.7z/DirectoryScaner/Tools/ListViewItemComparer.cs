﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DirectoryScaner.Tools
{
    class ListViewItemComparer : IComparer
    {
        int col;
        public ListViewItemComparer(Int32 num)
        {
            col = num;
        }

        public int Compare(object x, object y)
        {
            int num1 = Convert.ToInt32(((ListViewItem)x).SubItems[col].Text);
            int num2 = Convert.ToInt32(((ListViewItem)y).SubItems[col].Text);

            if (num1 > num2)
            {
                return 1;
            }
            
            return -1;
        }
    }
}
