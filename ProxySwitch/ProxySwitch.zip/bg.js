var i = 1;
chrome.browserAction.onClicked.addListener(function(tab) {
	console.log(i);
	
	if(i%3==1)
	{
		console.log("127.0.0.1:8080");
		var config = {
			mode: "pac_script",
			pacScript: {
				data: "function FindProxyForURL(url, host) {\n" +
				"return 'PROXY 127.0.0.1:8080; DIRECT';\n" +
				"}"
			}
		};
		
		chrome.proxy.settings.set(
			{value: config, scope: 'regular'},
			function() {}
		);
		chrome.browserAction.setBadgeText({text:"8080"});
	}else if(i%3==2){
		console.log("127.0.0.1:1080");
		var config = {
			mode: "pac_script",
			pacScript: {
				data: "function FindProxyForURL(url, host) {\n" +
				"return 'PROXY 127.0.0.1:1080; DIRECT';\n" +
				"}"
			}
		};
		
		chrome.proxy.settings.set(
			{value: config, scope: 'regular'},
			function() {}
		);
		chrome.browserAction.setBadgeText({text:"1080"});
	}else{
		console.log("DIRECT");
		var config = {
			mode: "pac_script",
			pacScript: {
				data: "function FindProxyForURL(url, host) {\n" +
					"   return 'DIRECT';\n" +
					"}"
			}
		};
		
		chrome.proxy.settings.set(
			{value: config, scope: 'regular'},
			function() {}
		);
		chrome.browserAction.setBadgeText({text:""});
	}

	i++;
});

