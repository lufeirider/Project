// Sniffer.cpp : �������̨Ӧ�ó������ڵ㡣
//



#include "stdafx.h"
#include <afxwin.h>


#include <winsock2.h>  
#include <ws2tcpip.h>  


#pragma comment (lib,"ws2_32.lib")  

#define SIO_RCVALL _WSAIOW(IOC_VENDOR,1)  

struct IpHead
{
	unsigned char h_len : 4;//4λ�ײ�����+4λIP�汾��  
	unsigned char ver : 4;
	unsigned char tos;//8λ��������TOS  
	unsigned short total_len;//16λ�ܳ��ȣ��ֽڣ�  
	unsigned short ident;//16λ��ʶ  
	unsigned short frag_and_flags;//3λ��־λ  
	unsigned char ttl;//8λ����ʱ�� TTL  
	unsigned char proto;//8λЭ�� (TCP, UDP ������)  
	unsigned short checksum;//16λIP�ײ�У���  
	unsigned int sourceip;//32λԴIP��ַ  
	unsigned int destip;//32λĿ��IP��ַ  
};

struct TcpHead //����TCP�ײ�  
{
	USHORT th_sport; //16λԴ�˿�  
	USHORT th_dport; //16λĿ�Ķ˿�  
	unsigned int th_seq; //32λ���к�  
	unsigned int th_ack; //32λȷ�Ϻ�  
	unsigned char th_lenres; //4λ�ײ�����/6λ������  
	unsigned char th_flag; //6λ��־λ  
	USHORT th_win; //16λ���ڴ�С  
	USHORT th_sum; //16λУ���  
	USHORT th_urp; //16λ��������ƫ����  
};


struct CC
{
	char szIp[100] = { 0 };
	int nCount = 0;
	int nShow = 0;
};


char *g_pHostList[10];//�о���������������  


wchar_t* AnsiToUnicode(const char* szStr)
{
	int nLen = MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, szStr, -1, NULL, 0);
	if (nLen == 0)
	{
		return NULL;
	}
	wchar_t* pResult = new wchar_t[nLen];
	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, szStr, -1, pResult, nLen);
	return pResult;
}

char* UnicodeToAnsi(const wchar_t* szStr)
{
	int nLen = WideCharToMultiByte(CP_ACP, 0, szStr, -1, NULL, 0, NULL, NULL);
	if (nLen == 0)
	{
		return NULL;
	}
	char* pResult = new char[nLen];
	WideCharToMultiByte(CP_ACP, 0, szStr, -1, pResult, nLen, NULL, NULL);
	return pResult;
}

DWORD _stdcall listen(void *p)
{

	//��ʱʱ��
	int m_nTimeOut = 1000;
	
	char m_szBuf[1500] = {0};//�������ݻ�����
	char m_szData[1500] = { 0 }; //���ܰ���data����
	struct IpHead *m_pIpHead;//����IPͷ�ṹ  
	struct TcpHead *m_pTcpHead;//����TCPͷ�ṹ  
	SOCKET m_Cs;
	struct sockaddr_in m_cAddr;

	m_Cs = socket(AF_INET, SOCK_RAW, IPPROTO_IP); //����һ��ԭʼ�׽���  

	//cc����ip��Ϣ����
	CC m_Cip[1000];

	//cc����ip������
	int m_nIpCount = 0;

	//����code
	int m_nExist = 0;

	//�Ƿ����cc���
	int m_nCheck = 1;

	//����code
	int m_nErr;

	//���ؽ��code
	int m_nRet;

	//http������
	CString m_csHtml;
	CString m_csHeader;
	CString m_csPath;

	char* m_pPath = NULL;

	//�����ַ�������
	int m_nIndex = 0;

	//Դip �� Ŀ��ip
	char* m_pDestIp;
	char* m_pSourceIp;

	//���˺�׺
	char* m_aSuffix[] = {".js",".css",".jpg",".png",".gif"};

	//SMB��֤����ʱ������ݰ�����
	char m_szSMB[] = { 0x00,0x00,0x02 }; //3
	char m_szRDP[] = { 0x16,0x03,0x01,0x04 };//4
	//ʱ��
	time_t t;
	int m_nOldTime;
	int m_nNewTime;


	m_nOldTime = time(&t);

	if (m_Cs == INVALID_SOCKET)
	{
		printf("socket() called failed! ,error code is: %d", WSAGetLastError());
		return -1;
	}

	setsockopt(m_Cs, SOL_SOCKET, SO_RCVTIMEO, (char*)&m_nTimeOut, sizeof(m_nTimeOut));

	memset(&m_cAddr, 0, sizeof(m_cAddr));
	m_cAddr.sin_family = AF_INET;
	m_cAddr.sin_addr.S_un.S_addr = inet_addr((char *)p);
	m_cAddr.sin_port = htons(0);//���ñ��ض˿ں�  
	m_nErr = bind(m_Cs, (struct sockaddr *)&m_cAddr, sizeof(m_cAddr));//�󶨶˿�  
	if (m_nErr == SOCKET_ERROR)
	{
		printf("bind() called failed! The error code is: %d\n", WSAGetLastError());
		return -1;
	}

	DWORD dwin = 1;
	DWORD dwout[10];
	DWORD dwret;
	WSAIoctl(m_Cs, SIO_RCVALL, &dwin, sizeof(dwin), &dwout, sizeof(dwout), &dwret, NULL, NULL);

	for (;;)
	{
		//��ʼ��
		m_nExist = 0;
		m_nCheck = 1;
		memset(m_szBuf, 0, sizeof(m_szBuf));


		m_nRet = recv(m_Cs, m_szBuf, sizeof(m_szBuf), 0);//��������  
		
		if (m_nRet == SOCKET_ERROR)
		{
			
			if (WSAGetLastError() == WSAETIMEDOUT)
			{
				continue;
			}
			closesocket(m_Cs);
			return 0;
		}

		m_pIpHead = (struct IpHead *)m_szBuf;//ȡ��IPͷ���ݵĵ�ַ  
		int iIphLen = sizeof(unsigned long) * (m_pIpHead->h_len & 0xf);
		m_pTcpHead = (struct TcpHead *)(m_szBuf + iIphLen);//ȡ��TCPͷ���ݵĵ�ַ  


		m_pDestIp = inet_ntoa(*(struct in_addr*)&m_pIpHead->destip);
		m_pSourceIp = inet_ntoa(*(struct in_addr*)&m_pIpHead->sourceip);


		switch (m_pIpHead->proto)//����IPͷ��Э���ж����ݰ�Э������  
		{
		case 1:
			break;
		case 2:
			break;
		case 6:
			if (ntohs(m_pTcpHead->th_dport) == 80)
			{
				//printf("============================================================\n");
				//printf("From : %s \t port %d\t\n", inet_ntoa(*(struct in_addr*)&m_pIpHead->sourceip), ntohs(m_pTcpHead->th_sport));
				//printf("To : %s \t port %d  \n", inet_ntoa(*(struct in_addr*)&m_pIpHead->destip), ntohs(m_pTcpHead->th_dport));
				//printf("============================================================\n");
				//printf("%s\n",(char*)m_pTcpHead + sizeof(TcpHead));
				if (strstr((char*)m_pTcpHead + sizeof(TcpHead), "HTTP/") != NULL)
				{
					//printf("============================================================\n");
					m_csHtml = AnsiToUnicode((char*)m_pTcpHead + sizeof(TcpHead));
					//printf("%S\n", (LPCTSTR)m_csHtml);

					m_nIndex = m_csHtml.Find(L"HTTP/");
					m_csHeader = m_csHtml.Left(m_nIndex);
					//printf("%S\n", m_csHeader);

					m_nIndex = m_csHeader.Find(L"/");
					m_nIndex = m_csHeader.GetLength() - m_nIndex;
					m_csPath = m_csHeader.Right(m_nIndex);
					//printf("%S\n", m_csPath);
					m_pPath = UnicodeToAnsi(m_csPath.GetBuffer(m_csPath.GetLength()));


					if (strstr(m_pPath, "?") == NULL)
					{
						for (m_nIndex = 0; m_nIndex < sizeof(m_aSuffix) / sizeof(char*); m_nIndex++)
						{
							if (strstr(m_pPath, m_aSuffix[m_nIndex]) != NULL)
							{
								printf("%S\n", m_csPath);
								m_nCheck = 0;
								break;
							}
						}
					}


					if (m_nCheck == 1)
					{

						for (int i = 0; i < m_nIpCount; i++)
						{
							if (strstr(m_Cip[i].szIp, m_pSourceIp) != NULL)
							{
								m_Cip[i].nCount = m_Cip[i].nCount + 1;

								if (m_Cip[i].nCount > 20)
								{
									if (m_Cip[i].nShow == 0)
									{
										printf("ip = %s ban \n", m_Cip[i].szIp);
										m_Cip[i].nShow = 1;
									}

								}

								m_nExist = 1;
								break;
							}
						}

						if (m_nExist == 0)
						{

							strcpy(m_Cip[m_nIpCount].szIp, m_pSourceIp);
							m_Cip[m_nIpCount].nCount = 1;

							m_nIpCount = m_nIpCount + 1;
						}
					}



					//sprintf("============================================================\n");
				}

				m_nNewTime = time(&t);
				if (m_nNewTime - m_nOldTime > 5)
				{
					m_nIpCount = 0;
					m_nOldTime = time(&t);
					memset(m_Cip, 0, sizeof(m_Cip));
				}
			}
			
			if (ntohs(m_pTcpHead->th_sport) == 445)
			{
				memset(m_szData,0,1500);
				memcpy(m_szData, (char*)m_pTcpHead + sizeof(TcpHead),1500);
				if (memcmp(m_szSMB, m_szData, 3) == 0)
				{
					printf("%s ���� 445�˿�\n", inet_ntoa(*(struct in_addr*)&m_pIpHead->sourceip));
				}
			}


			if (ntohs(m_pTcpHead->th_sport) == 3389)
			{
				memset(m_szData, 0, 1500);
				memcpy(m_szData, (char*)m_pTcpHead + sizeof(TcpHead), 1500);
				if (memcmp(m_szRDP, m_szData, 4) == 0)
				{
					printf("%s ���� 3389�˿�\n", inet_ntoa(*(struct in_addr*)&m_pIpHead->destip));
				}
				
			}

			if (ntohs(m_pTcpHead->th_dport) == 1433)
			{
				printf("%s ���� 1433�˿�", inet_ntoa(*(struct in_addr*)&m_pIpHead->sourceip));
			}

			if (ntohs(m_pTcpHead->th_dport) == 3306)
			{
				printf("%s ���� 3306�˿�", inet_ntoa(*(struct in_addr*)&m_pIpHead->sourceip));
			}
			break;
		case 17:
			break;
		}

	}

	return 1;
}

void main()
{
	//��ʼ��sock  
	WSADATA m_Cwsa;
	int m_nIndex = 0;
	int m_nErr;
	DWORD m_dwThreadId;
	char m_szName[128] = {0};
	hostent *m_pHost;

	m_nErr = WSAStartup(MAKEWORD(2, 1), &m_Cwsa);
	if (m_nErr != 0)
	{
		printf("WSAStartup() called failed!\n");
	}

	gethostname(m_szName, sizeof(m_szName));
	m_pHost = gethostbyname(m_szName);
	while (m_pHost->h_addr_list[m_nIndex] != NULL)//ȡ����������ţ�Ϊÿ����������һ�������߳�  
	{
		g_pHostList[m_nIndex] = (char *)malloc(16);
		sprintf(g_pHostList[m_nIndex], "%s", inet_ntoa(*(struct in_addr *)m_pHost->h_addr_list[m_nIndex]));
		printf("Bind to %s\n", g_pHostList[m_nIndex]);
		CreateThread(NULL, 0, listen, g_pHostList[m_nIndex], 0, &m_dwThreadId);
		m_nIndex++;
	}

	for (;;)//Ϊÿ���������������̺߳�Ҫ��һ��ѭ����ֹ���߳��˳�  
	{
		Sleep(10);
	}
}