import requests

timeout = 1.0
proxies = dict(http='socks5://115.159.205.67:1080',https='socks5://115.159.205.67:1080')

resp = requests.get('http://2017.ip138.com/ic.asp', proxies=proxies ,timeout=timeout)
								 
print(resp.text.encode('UTF-8'))