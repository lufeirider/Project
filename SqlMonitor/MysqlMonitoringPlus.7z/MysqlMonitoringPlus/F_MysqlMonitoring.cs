﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Threading;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace MysqlMonitoringPlus
{
    public partial class F_MysqlMonitoring : Form
    {
        public F_MysqlMonitoring()
        {
            InitializeComponent();
        }

        //断点时间
        string var_datatime = "";
        Int32 flag = 0;

        BindingSource Bs = null;

        MySqlConnection myCon;
        Thread t;

        #region  建立MySql数据库连接
        /// <summary>    
        /// 建立数据库连接.    
        /// </summary>    
        /// <returns>返回MySqlConnection对象</returns>
        public MySqlConnection func_getmysqlcon()
        {
            string M_str_sqlcon = "server=" + txt_host.Text + ";user id=" + txt_user.Text + ";password=" + txt_pass.Text + ";database=mysql";

            MySqlConnection myCon = new MySqlConnection(M_str_sqlcon);
            myCon.Open();
            return myCon;
        }
        #endregion


        #region  执行MySqlCommand命令
        /// <summary>    
        /// 执行MySqlCommand    
        /// </summary>    
        /// <param name="M_str_sqlstr">SQL语句</param>    
        public int func_getmysqlcom(string M_str_sqlstr)
        {
            int count = 0;
            MySqlConnection mysqlcon = myCon;
            //mysqlcon.Open();
            MySqlCommand mysqlcom = new MySqlCommand(M_str_sqlstr, mysqlcon);
            count = mysqlcom.ExecuteNonQuery();
            //mysqlcom.Dispose();
            //mysqlcon.Close();
            //mysqlcon.Dispose();
            return count;
        }
        #endregion

        public bool ValidateSQL(string sql)
        {
            Regex ex = new Regex("'");
            if (ex.Matches(sql).Count % 2 != 0)
            {
                return false;
            }

            ex = new Regex("\"");
            if (ex.Matches(sql).Count % 2 != 0)
            {
                return false;
            }

            return true;
        }


        #region  创建MySqlDataReader对象
        /// <summary>   
        /// 创建一个MySqlDataReader对象    
        /// </summary>    
        /// <param name="M_str_sqlstr">SQL语句</param>    
        /// <returns>返回MySqlDataReader对象</returns>    
        public DataSet func_getmysqlread(string M_str_sqlstr)
        {
            MySqlConnection mysqlcon = myCon;
            //mysqlcon.Open();

            MySqlDataAdapter sda = new MySqlDataAdapter(M_str_sqlstr, mysqlcon);
            //MySqlCommand mysqlcom = new MySqlCommand(M_str_sqlstr, mysqlcon);

            //mysqlcon.Close();
            DataSet ds = new DataSet();
            sda.Fill(ds);
            //MySqlDataReader mysqlread = mysqlcom.ExecuteReader(CommandBehavior.CloseConnection);
            return ds;
        }
        #endregion


        #region 更新数据
        public void UpdateData()
        {
            flag = 0;
            while (true)
            {
                if (flag ==1)
                {
                    break;
                }
                string sql = "select event_time,argument from mysql.general_log where command_type='Query' " +
                    "and argument not like 'set global general_log=on;SET GLOBAL log_output%' " +
                    "and user_host like '" + textBox_FilterUsername.Text + "%'" +
                    "and( argument like 'select%'" +
                    "or argument like 'insert%'" +
                    "or argument like 'update%'" +
                    "or argument like 'delete%')" +
                    "and argument not like 'select %event_time%,%argument from%' " +
                    "and event_time>'" + var_datatime + "'";
                DataSet ds = func_getmysqlread(sql);


                System.Diagnostics.Debug.WriteLine(ds.Tables[0].Rows.Count);


                DataTableCollection tables = ds.Tables;
                DataView view1 = new DataView(tables[0]);

                Bs = new BindingSource();
                Bs.DataSource = view1;

                if(ds.Tables[0].Rows.Count != 0)
                    UpdateDataGridView(ds);
                //UpdateDataGridView(Bs);
                //dataGridView1.DataSource = Bs;


                //txt_count.Text = "行数：" + Bs.Count;
                UpdateText(Bs.Count.ToString());
                //dataGridView1.Columns[0].HeaderText = "查询时间";
                //dataGridView1.Columns[1].HeaderText = "查询语句";

                //dataGridView1.Columns[0].Width = 150;
                ////dataGridView1.Columns[1].Width = dataGridView1.Width - dataGridView1.Columns[0].Width - 10;
                //dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                //}
                //catch (Exception)
                //{
                //    MessageBox.Show("数据库出错，请检查连接信息以及确认mysql版本在5.1.6以上", "提示");
                //}

                Thread.Sleep(1000);
            }
            
        }
        #endregion

        delegate void UpdateTextHandler(String str);
        private void UpdateText(String str)
        {
            if (InvokeRequired)
            {
                Invoke(new UpdateTextHandler(UpdateText), str);
                return;
            }
            txt_count.Text = "行数：" + str;
        }

        delegate void UpdateDataGridViewHandler(DataSet ds);
        private void UpdateDataGridView(DataSet ds)
        {
            string sql;
            if (InvokeRequired)
            {
                Invoke(new UpdateDataGridViewHandler(UpdateDataGridView), ds);
                return;
            }



            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                int index = this.dataGridView1.Rows.Add();
                this.dataGridView1.Rows[index].Cells[0].Value = ds.Tables[0].Rows[i][0].ToString();
                this.dataGridView1.Rows[index].Cells[1].Value = ds.Tables[0].Rows[i][1].ToString();

                var_datatime = ds.Tables[0].Rows[i][0].ToString();
                System.Diagnostics.Debug.WriteLine(ds.Tables[0].Rows[i][1].ToString());

            }




            if (dataGridView1.Rows.Count != 0)
            {
                foreach (DataGridViewRow dgr in dataGridView1.Rows)
                {
                    sql = dgr.Cells[1].Value.ToString().ToLower();
                    if (sql.IndexOf("explain") != 0)
                    {
                        System.Diagnostics.Debug.WriteLine(sql);
                        if (!ValidateSQL("explain " + sql))
                        {
                            dgr.DefaultCellStyle.ForeColor = Color.Red;
                        }

                    }

                    
                }
            }


        }


        private void button1_Click(object sender, EventArgs e)
        {
            var_datatime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            txt_break.Text = "断点：" + var_datatime;
            myCon = func_getmysqlcon();
            func_getmysqlcom("set global general_log=on;SET GLOBAL log_output='table';");
            func_getmysqlcom("truncate table general_log;");
        }


        

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();

            var_datatime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            txt_break.Text = "断点：" + var_datatime;
            myCon = func_getmysqlcon();
            func_getmysqlcom("set global general_log=on;SET GLOBAL log_output='table';");
            func_getmysqlcom("truncate table general_log;");

            
            t = new Thread(new ThreadStart(UpdateData));
            t.Start();
        }

        private void F_MysqlMonitoring_Load(object sender, EventArgs e)
        {
            DataGridViewTextBoxColumn TimeHeader = new DataGridViewTextBoxColumn();
            TimeHeader.Name = "查询时间";
            TimeHeader.DataPropertyName = "查询时间";
            TimeHeader.HeaderText = "查询时间";
            dataGridView1.Columns.Add(TimeHeader);

            DataGridViewTextBoxColumn SqlHeader = new DataGridViewTextBoxColumn();
            SqlHeader.Name = "查询语句";
            SqlHeader.DataPropertyName = "查询语句";
            SqlHeader.HeaderText = "查询语句";
            dataGridView1.Columns.Add(SqlHeader);

            dataGridView1.Columns[0].Width = 150;
            dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;


            var_datatime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            txt_break.Text = "断点：" + var_datatime;
            
        }

        private void 复制ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count>0)
            {
                Clipboard.SetDataObject(dataGridView1.SelectedRows[0].Cells[1].Value.ToString());
            }
        }



        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void txt_searchkey_TextChanged(object sender, EventArgs e)
        {
            if (Bs!=null)
            {
                Bs.RemoveFilter();
                if (txt_searchkey.Text != "")
                {
                    Bs.Filter = "argument like '%" + txt_searchkey.Text.Replace("'","\\'") + "%'";
                    //dataGridView1.Refresh();
                    txt_count.Text = "行数：" + Bs.Count;
                }
                else
                {
                    txt_count.Text = "行数：" + Bs.Count;
                }
            }            
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            flag = 1;
            t.Abort();

        }

        private void button4_Click(object sender, EventArgs e)
        {
        }
    }
}
