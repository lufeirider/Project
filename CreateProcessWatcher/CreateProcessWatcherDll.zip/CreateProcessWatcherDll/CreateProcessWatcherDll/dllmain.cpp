// dllmain.cpp : ���� DLL Ӧ�ó������ڵ㡣
#include "stdafx.h"

#include <windows.h>

#include <stdio.h>

PROC	pCreateProcessAOldAddress = (PROC)CreateProcessA;
PROC	pCreateProcessWOldAddress = (PROC)CreateProcessW;
PROC	pCreateProcessANewAddress;
PROC	pCreateProcessWNewAddress;
PROC*	dwAddress;

void test()
{
	HANDLE hPipe;
	DWORD dwRead, dwWrite;
	char sebuf[] = "lufei this is client!";
	char rebuf[100];

	/*���ӹܵ�����*****************************************************/
	if (!WaitNamedPipe("\\\\.\\pipe\\Communication", NMPWAIT_WAIT_FOREVER))
	{
		OutputDebugString("��ǰû�п����õ������ܵ�ʵ����\n");
		return;
	}

	/*�򿪹ܵ�����*****************************************************/
	hPipe = CreateFile("\\\\.\\pipe\\Communication", GENERIC_READ | GENERIC_WRITE,
		0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (INVALID_HANDLE_VALUE == hPipe)
	{
		char szProcessInfo[255] = { 0 };
		OutputDebugString("�������ܵ�ʧ�ܣ�\n");
		sprintf(szProcessInfo, "errorcode = %d", GetLastError());
		OutputDebugString(szProcessInfo);
		hPipe = NULL;
		return;
	}

	/*��д�ܵ�����*****************************************************/
	//д������
	if (!WriteFile(hPipe, sebuf, strlen(sebuf) + 1, &dwWrite, NULL))
	{
		OutputDebugString("д������ʧ�ܣ�\n");
		return;
	}

	OutputDebugString("rebuf\n");
	CloseHandle(hPipe);
}


void WritePipeData(char* sebuf)
{
	HANDLE hPipe;
	DWORD dwRead, dwWrite;
	//char sebuf[] = "lufei this is client!";
	char rebuf[100];


	/*���ӹܵ�����*****************************************************/
	if (!WaitNamedPipe("\\\\.\\pipe\\Communication", NMPWAIT_WAIT_FOREVER))
	{
		OutputDebugString("��ǰû�п����õ������ܵ�ʵ����\n");

		return;
	}

	/*�򿪹ܵ�����*****************************************************/
	hPipe = CreateFile("\\\\.\\pipe\\Communication", GENERIC_READ | GENERIC_WRITE,
		0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (INVALID_HANDLE_VALUE == hPipe)
	{
		OutputDebugString("�������ܵ�ʧ�ܣ�\n");
		hPipe = NULL;

		return;
	}

	/*��д�ܵ�����*****************************************************/
	//д������
	if (!WriteFile(hPipe, sebuf, strlen(sebuf) + 1, &dwWrite, NULL))
	{
		OutputDebugString("д������ʧ�ܣ�\n");
		CloseHandle(hPipe);
		return;
	}

	OutputDebugString("rebuf\n");
	CloseHandle(hPipe);

}

char* UnicodeToAnsi(const wchar_t* szStr)
{
	int nLen = WideCharToMultiByte(CP_ACP, 0, szStr, -1, NULL, 0, NULL, NULL);
	if (nLen == 0)
	{
		return NULL;
	}
	char* pResult = new char[nLen];
	WideCharToMultiByte(CP_ACP, 0, szStr, -1, pResult, nLen, NULL, NULL);
	return pResult;
}

BOOL ApiHook(char* DllName, PROC pOldAddress, PROC pNewAddress)
{
	HMODULE						lpBase;
	IMAGE_DOS_HEADER*			pDosHeader;
	IMAGE_NT_HEADERS*			pNtHeaders;
	IMAGE_IMPORT_DESCRIPTOR*	pDescripTor;
	IMAGE_THUNK_DATA*			pThunk;
	//////////////////////////////////////////////////////////////////////////
	lpBase = GetModuleHandle("wshom.ocx");
	//lpBase = GetModuleHandle("cmd.exe");
	pDosHeader = (IMAGE_DOS_HEADER*)lpBase;
	pNtHeaders = (IMAGE_NT_HEADERS*)((BYTE*)lpBase + pDosHeader->e_lfanew);
	pDescripTor = (IMAGE_IMPORT_DESCRIPTOR*)((BYTE*)lpBase + pNtHeaders->OptionalHeader.DataDirectory[1].VirtualAddress);

	while (pDescripTor->FirstThunk)
	{
		char* Name = (char*)((BYTE*)lpBase + pDescripTor->Name);
		//OutputDebugStringA(Name);
		if (stricmp(Name, DllName) == 0)
		{
			break;
		}
		pDescripTor++;
	}

	pThunk = (IMAGE_THUNK_DATA*)((BYTE*)lpBase + pDescripTor->FirstThunk);

	while (pThunk->u1.Function)
	{
		dwAddress = (PROC*)&pThunk->u1.Function;	//ȡ�ú�����ַ

		//char szBuff[255] = { 0 };

		if (*dwAddress == (PROC)pOldAddress)
		{
			//�޸ĵ�ַ��!!!
			DWORD flOldProtect;
			VirtualProtect(dwAddress, sizeof(PROC), PAGE_READWRITE, &flOldProtect);

			//char szBuff[255] = { 0 };

			//sprintf(szBuff, "JMP Address  = %x", dwAddress);
			//OutputDebugStringA(szBuff);



			//sprintf(szBuff, "dwAddress  = %x", dwAddress);
			//OutputDebugStringA(szBuff);

			//sprintf(szBuff, "pOldAddress  = %x", pOldAddress);
			//OutputDebugStringA(szBuff);

			//sprintf(szBuff, "pNewAddress  = %x", pNewAddress);
			//OutputDebugStringA(szBuff);

			//OutputDebugStringA("modify ok");
			WriteProcessMemory(GetCurrentProcess(), dwAddress, &pNewAddress, sizeof(PROC), NULL);
			VirtualProtect(dwAddress, sizeof(PROC), flOldProtect, &flOldProtect);
			break;
		}
		pThunk++;
	}

	return TRUE;
}


BOOL
WINAPI
MyCreateProcessW(
	_In_opt_ LPCWSTR lpApplicationName,
	_Inout_opt_ LPWSTR lpCommandLine,
	_In_opt_ LPSECURITY_ATTRIBUTES lpProcessAttributes,
	_In_opt_ LPSECURITY_ATTRIBUTES lpThreadAttributes,
	_In_ BOOL bInheritHandles,
	_In_ DWORD dwCreationFlags,
	_In_opt_ LPVOID lpEnvironment,
	_In_opt_ LPCWSTR lpCurrentDirectory,
	_In_ LPSTARTUPINFOW lpStartupInfo,
	_Out_ LPPROCESS_INFORMATION lpProcessInformation
)
{

	

	WCHAR szProcessInfo[255] = { 0 };

	if (wcslen(lpCommandLine) != 0)
	{
		wcscpy(szProcessInfo, lpCommandLine);
	}
	else
	{
		wcscpy(szProcessInfo, lpApplicationName);
	}
	OutputDebugStringW(szProcessInfo);

	WritePipeData(UnicodeToAnsi(szProcessInfo));

	//COPYDATASTRUCT cds = { NULL, sizeof(szProcessInfo), (void *)&szProcessInfo };


	//if (SendMessage(FindWindowA("CreateProcessWatcher", NULL), WM_COPYDATA, GetCurrentProcessId(), (LPARAM)&cds) != -1)
	//{
	//	swprintf(szProcessInfo, L"errorcode = %d", GetLastError());
	//	OutputDebugStringW(szProcessInfo);
	//}

	ApiHook("KERNEL32.dll", pCreateProcessWNewAddress, pCreateProcessWOldAddress);
	BOOL bRet = CreateProcessW(
		lpApplicationName,
		lpCommandLine,
		lpProcessAttributes,
		lpThreadAttributes,
		bInheritHandles,
		dwCreationFlags,
		lpEnvironment,
		lpCurrentDirectory,
		lpStartupInfo,
		lpProcessInformation
	);
	ApiHook("KERNEL32.dll", pCreateProcessWOldAddress, pCreateProcessWNewAddress);


	return bRet;
}

BOOL
WINAPI
MyCreateProcessA(
	_In_opt_ LPCSTR lpApplicationName,
	_Inout_opt_ LPSTR lpCommandLine,
	_In_opt_ LPSECURITY_ATTRIBUTES lpProcessAttributes,
	_In_opt_ LPSECURITY_ATTRIBUTES lpThreadAttributes,
	_In_ BOOL bInheritHandles,
	_In_ DWORD dwCreationFlags,
	_In_opt_ LPVOID lpEnvironment,
	_In_opt_ LPCSTR lpCurrentDirectory,
	_In_ LPSTARTUPINFOA lpStartupInfo,
	_Out_ LPPROCESS_INFORMATION lpProcessInformation
)
{
	OutputDebugStringA(lpApplicationName);
	ApiHook("KERNEL32.dll", pCreateProcessANewAddress, pCreateProcessAOldAddress);
	BOOL bRet = CreateProcessA(
		lpApplicationName,
		lpCommandLine,
		lpProcessAttributes,
		lpThreadAttributes,
		bInheritHandles,
		dwCreationFlags,
		lpEnvironment,
		lpCurrentDirectory,
		lpStartupInfo,
		lpProcessInformation
	);
	ApiHook("KERNEL32.dll", pCreateProcessAOldAddress, pCreateProcessANewAddress);
	return bRet;
}

BOOL APIENTRY DllMain(HMODULE hModule,
	DWORD  ul_reason_for_call,
	LPVOID lpReserved
)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	{
		LoadLibrary("wshom.ocx");

		pCreateProcessWNewAddress = (PROC)MyCreateProcessW;
		ApiHook("KERNEL32.dll", pCreateProcessWOldAddress, pCreateProcessWNewAddress);

		//char szBuff[255] = { 0 };

		//sprintf(szBuff, "pCreateProcessWOldAddress  = %x", pCreateProcessWOldAddress);
		//OutputDebugStringA(szBuff);

		//sprintf(szBuff, "pCreateProcessWNewAddress  = %x", pCreateProcessWNewAddress);
		//OutputDebugStringA(szBuff);

		pCreateProcessANewAddress = (PROC)MyCreateProcessA;
		ApiHook("KERNEL32.dll", pCreateProcessAOldAddress, pCreateProcessANewAddress);
		break;
	}
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

