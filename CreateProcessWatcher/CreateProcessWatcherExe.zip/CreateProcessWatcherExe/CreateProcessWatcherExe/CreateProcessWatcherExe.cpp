// CreateProcessWatcherExe.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"


#include <windows.h>
#include <tlhelp32.h>
#pragma comment(lib, "Advapi32.lib")   

#include <comdef.h>  
#include <Wbemidl.h> 
#pragma comment(lib, "wbemuuid.lib")  

#include <Winuser.h>


int InjectDllById(DWORD dwId)
{
	DWORD		dwProcessId;
	HANDLE		hProcess;
	LPVOID		ParameterAddress;
	char		DllName[255] = { 0 };
	SIZE_T		dwWirite;
	LPVOID		lpLibraryAddress;
	HANDLE		hRemote;
	char		szCurrentDirectory[255] = { 0 };
	//////////////////////////////////////////////////////////////////////////������


	GetCurrentDirectoryA(255, szCurrentDirectory);
	strcat(szCurrentDirectory, "CreateProcessWatcherDll.dll");
	strcpy(DllName, szCurrentDirectory);
	OutputDebugStringA(DllName);

	dwProcessId = dwId;
	if (dwProcessId == NULL)
	{
		printf("GetProcessId Error \n");
		getchar();
		return 0;
	}

	hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwProcessId);
	if (hProcess == NULL)
	{

		printf("GetLastError = %d", GetLastError());
		printf("OpenProcess Error \n");
		getchar();
		return 0;
	}

	ParameterAddress = VirtualAllocEx(hProcess, NULL, 200, MEM_COMMIT, PAGE_READWRITE);
	if (ParameterAddress == NULL)
	{
		printf("VirtualAllocEx Error \n");
		getchar();
		return 0;
	}

	if (!WriteProcessMemory(hProcess, ParameterAddress, (LPCVOID)DllName, strlen(DllName), &dwWirite))
	{
		printf("WriteProcessMemory Error \n");
		getchar();
		return 0;
	}

	lpLibraryAddress = GetProcAddress(LoadLibraryA("Kernel32.dll"), "LoadLibraryA");
	if (lpLibraryAddress == NULL)
	{
		printf("GetProcAddress + LoadLibraryA Error \n");
		getchar();
		return 0;
	}

	hRemote = CreateRemoteThread(hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)lpLibraryAddress, ParameterAddress, 0, NULL);
	if (hRemote == NULL)
	{
		printf("CreateRemoteThread Error \n");
		getchar();
		return 0;
	}
}


int WathcerW3wp()
{
	HRESULT hres;

	hres = CoInitializeEx(0, COINIT_MULTITHREADED);
	if (FAILED(hres))
	{
		//cout << "Failed to initialize COM library. "
		//	<< "Error code = 0x"
		//	<< hex << hres << endl;
		OutputDebugString("Failed to initialize COM library.");
		return 1;
	}

	IWbemLocator *pLoc = 0;
	HRESULT hr;

	hr = CoCreateInstance(CLSID_WbemLocator, 0,
		CLSCTX_INPROC_SERVER, IID_IWbemLocator, (LPVOID *)&pLoc);

	if (FAILED(hr))
	{
		//cout << "Failed to create IWbemLocator object. Err code = 0x"
		//	<< hex << hr << endl;
		OutputDebugStringA("Failed to create IWbemLocator object");
		return hr;     // Program has failed.
	}

	IWbemServices *pSvc = 0;

	bstr_t strNetworkResource("ROOT\\CIMV2");

	hr = pLoc->ConnectServer(
		strNetworkResource,
		NULL, NULL, 0, NULL, 0, 0, &pSvc);

	if (FAILED(hr))
	{
		//cout << "Could not connect. Error code = 0x"
		//	<< hex << hr << endl;

		pLoc->Release();
		CoUninitialize();
		return hr;      // Program has failed.
	}

	//cout << "Connected to WMI" << endl;

	// Set the proxy so that impersonation of the client occurs.
	hr = CoSetProxyBlanket(pSvc,
		RPC_C_AUTHN_WINNT,
		RPC_C_AUTHZ_NONE,
		NULL,
		RPC_C_AUTHN_LEVEL_CALL,
		RPC_C_IMP_LEVEL_IMPERSONATE,
		NULL,
		EOAC_NONE
	);

	if (FAILED(hr))
	{
		//cout << "Could not set proxy blanket. Error code = 0x"
		//	<< hex << hr << endl;
		pSvc->Release();
		pLoc->Release();
		CoUninitialize();
		return hr;
	}


	bstr_t strLang("WQL");
	//����w3wp.exe���̴���
	bstr_t strQuery("SELECT * FROM __InstanceCreationEvent WITHIN 1 WHERE TargetInstance ISA 'Win32_Process' AND TargetInstance.Name = 'w3wp.exe'");
	IEnumWbemClassObject* pResult = NULL;

	hr = pSvc->ExecNotificationQuery(strLang, strQuery, WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, NULL, &pResult);
	if (SUCCEEDED(hr))
	{
		do {
			IWbemClassObject* pObject = NULL;
			ULONG lCnt = 0;
			hr = pResult->Next(WBEM_INFINITE, 1, &pObject, &lCnt);


			VARIANT vtInstanceObject;

			hr = pObject->Get(L"TargetInstance", 0, &vtInstanceObject, NULL, NULL);
			if (SUCCEEDED(hr) && vtInstanceObject.vt == VT_UNKNOWN && vtInstanceObject.punkVal != NULL)
			{
				IWbemClassObject *pTargetInstance = (IWbemClassObject*)vtInstanceObject.punkVal;
				VARIANT vtProcessID, vtExecutablePath;

				hr = pTargetInstance->Get(L"ProcessID", 0, &vtProcessID, NULL, NULL);
				if (SUCCEEDED(hr))
				{
					InjectDllById(vtProcessID.ulVal);
					printf("ProcessID=%d\n", vtProcessID.ulVal);
				}

				hr = pTargetInstance->Get(L"ExecutablePath", 0, &vtExecutablePath, NULL, NULL);
				if (SUCCEEDED(hr) && vtExecutablePath.vt == VT_BSTR)
				{
					char* szPath = _com_util::ConvertBSTRToString(vtExecutablePath.bstrVal);
					printf("ExecutablePath=%s\n", szPath);

					SysFreeString(vtExecutablePath.bstrVal);
				}

				vtInstanceObject.punkVal->Release();
			}

		} while (true);
	}



	pSvc->Release();
	pLoc->Release();
	CoUninitialize();
	CoUninitialize();

}


bool EnableDebugPrivilege()
{
	HANDLE hToken;
	LUID sedebugnameValue;
	TOKEN_PRIVILEGES tkp;
	if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
	{
		return   FALSE;
	}
	if (!LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &sedebugnameValue))
	{
		CloseHandle(hToken);
		return false;
	}
	tkp.PrivilegeCount = 1;
	tkp.Privileges[0].Luid = sedebugnameValue;
	tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	if (!AdjustTokenPrivileges(hToken, FALSE, &tkp, sizeof(tkp), NULL, NULL))
	{
		CloseHandle(hToken);
		return false;
	}
	return true;
}


void ReadPipeData()
{
	HANDLE hPipe, hEvent;;
	DWORD dwRead;
	OVERLAPPED ovlap;
	char szbuff[255] = { 0 };

	SECURITY_ATTRIBUTES sa;
	SECURITY_DESCRIPTOR sd;

	InitializeSecurityDescriptor(&sd, SECURITY_DESCRIPTOR_REVISION);
	SetSecurityDescriptorDacl(&sd, TRUE, NULL, FALSE);
	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.bInheritHandle = TRUE;
	sa.lpSecurityDescriptor = &sd;
	/*������������*****************************************************/
	hPipe = CreateNamedPipe("\\\\.\\pipe\\Communication",
		PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
		0, 1, 1024, 1024, 0, &sa);
	if (INVALID_HANDLE_VALUE == hPipe)
	{
		printf("���������ܵ�ʧ�ܣ�\n");
		hPipe = NULL;
		return;
	}

	/*���������ܵ�����*************************************************/
	hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	if (!hEvent)
	{
		printf("�����¼�����ʧ�ܣ�\n");
		CloseHandle(hPipe);
		hPipe = NULL;
		return;
	}



	ZeroMemory(&ovlap, sizeof(OVERLAPPED));
	ovlap.hEvent = hEvent;

	//�����ܵ�����
	if (!ConnectNamedPipe(hPipe, &ovlap))
	{
		if (ERROR_IO_PENDING != GetLastError())
		{
			printf("�ȴ��ͻ�������ʧ�ܣ�\n");
			CloseHandle(hPipe);
			CloseHandle(hEvent);
			hPipe = NULL;
			return;
		}
	}


	ResetEvent(hEvent);
	//�ȴ��ͻ�������
	if (WAIT_FAILED == WaitForSingleObject(hEvent, INFINITE))
	{
		printf("�ȴ�����ʧ�ܣ�");
		CloseHandle(hPipe);
		CloseHandle(hEvent);
		hPipe = NULL;
		return;
	}



	//hEvent=CreateEvent(NULL,fALSE,FALSE,NULL);
	/*��д�ܵ�����*****************************************************/
	if (!ReadFile(hPipe, szbuff, 100, &dwRead, NULL))
	{
		printf("��ȡ����ʧ�ܣ�\n");

		return;
	}
	printf(szbuff);
	printf("\n");
	CloseHandle(hPipe);
}


static DWORD WINAPI thread_access(LPVOID args)
{
	while (true)
	{
		ReadPipeData();
	}
	return 1;
}


int main()
{

	DWORD id;
	HANDLE hThread = CreateThread(NULL, 0, thread_access, NULL, 0, &id);
	EnableDebugPrivilege();
	WathcerW3wp();


	getchar();
	return 0;
}

