<?php
error_reporting(0); 
$ipArr = array(
"jidianlou" => "机电楼",
"35dong" => "35栋",
"gongonglou" => "公共楼"
);

foreach($ipArr as $k=>$v)
{
	if(file_exists($k))
	{
		echo $v."有电<br/>";
	}
	else
	{
		echo $v."没电<br/>";
	}
}


	
	
?>