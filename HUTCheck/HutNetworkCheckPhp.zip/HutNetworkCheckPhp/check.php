<?php
//error_reporting(0); 
$ipToNameArr = array(
"192.168.181.1" => "jidianlou",
"172.22.128.235" => "35dong",
"192.168.193.1" => "gongonglou"
);

$ipArr = explode("|",$_GET['ip']);


foreach($ipArr as $k => $v)
{
	$fileName = $ipToNameArr[$v];

	$file = fopen($fileName, "w");
	fwrite($file,time());
	fclose($file);
}


sleep(5);


foreach($ipArr as $k => $v)
{
	$fileName = $ipToNameArr[$v];
	$file = fopen($fileName, "r");
	$oldTime = fread($file,10);
	fclose($file);

	if((time()-$oldTime)>4)
	{
		@unlink($fileName);
	}
}

?>