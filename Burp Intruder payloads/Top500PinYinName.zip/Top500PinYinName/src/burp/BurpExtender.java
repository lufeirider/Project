package burp;

import java.io.PrintWriter;

public class BurpExtender implements IBurpExtender, IIntruderPayloadGeneratorFactory
{
    private IExtensionHelpers helpers;
    private PrintWriter stdout;

    // hard-coded payloads
    // [in reality, you would use an extension for something cleverer than this]
     byte[][] PAYLOADS = new byte[][]{"zhangwei".getBytes(),"wangwei".getBytes(),"wangfang".getBytes(),"liwei".getBytes(),"lina".getBytes(),"zhangmin".getBytes(),"lijing".getBytes(),"wangjing".getBytes(),"liuwei".getBytes(),"wangxiuying".getBytes(),"zhangli".getBytes(),"lixiuying".getBytes(),"wangli".getBytes(),"zhangjing".getBytes(),"zhangxiuying".getBytes(),"liqiang".getBytes(),"wangmin".getBytes(),"limin".getBytes(),"wanglei".getBytes(),"liuyang".getBytes(),"wangyan".getBytes(),"wangyong".getBytes(),"lijun".getBytes(),"zhangyong".getBytes(),"lijie".getBytes(),"zhangjie".getBytes(),"zhanglei".getBytes(),"wangqiang".getBytes(),"lijuan".getBytes(),"wangjun".getBytes(),"zhangyan".getBytes(),"zhangtao".getBytes(),"wangtao".getBytes(),"liyan".getBytes(),"wangchao".getBytes(),"liming".getBytes(),"liyong".getBytes(),"wangjuan".getBytes(),"liujie".getBytes(),"liumin".getBytes(),"lixia".getBytes(),"lili".getBytes(),"zhangjun".getBytes(),"wangjie".getBytes(),"zhangqiang".getBytes(),"wangxiulan".getBytes(),"wanggang".getBytes(),"wangping".getBytes(),"liufang".getBytes(),"zhangyan".getBytes(),"liuyan".getBytes(),"liujun".getBytes(),"liping".getBytes(),"wanghui".getBytes(),"wangyan".getBytes(),"chenjing".getBytes(),"liuyong".getBytes(),"liling".getBytes(),"liguiying".getBytes(),"wangdan".getBytes(),"ligang".getBytes(),"lidan".getBytes(),"liping".getBytes(),"wangpeng".getBytes(),"liutao".getBytes(),"chenwei".getBytes(),"zhanghua".getBytes(),"liujing".getBytes(),"litao".getBytes(),"wangguiying".getBytes(),"zhangxiulan".getBytes(),"lihong".getBytes(),"lichao".getBytes(),"liuli".getBytes(),"zhangguiying".getBytes(),"wangyulan".getBytes(),"liyan".getBytes(),"zhangpeng".getBytes(),"lixiulan".getBytes(),"zhangchao".getBytes(),"wangling".getBytes(),"zhangling".getBytes(),"lihua".getBytes(),"wangfei".getBytes(),"zhangyulan".getBytes(),"wangguilan".getBytes(),"wangying".getBytes(),"liuqiang".getBytes(),"chenxiuying".getBytes(),"liying".getBytes(),"lihui".getBytes(),"limei".getBytes(),"chenyong".getBytes(),"wangxin".getBytes(),"lifang".getBytes(),"zhangguilan".getBytes(),"libo".getBytes(),"yangyong".getBytes(),"wangxia".getBytes(),"liguilan".getBytes(),"wangbin".getBytes(),"lipeng".getBytes(),"zhangping".getBytes(),"zhangli".getBytes(),"zhanghui".getBytes(),"zhangyu".getBytes(),"liujuan".getBytes(),"libin".getBytes(),"wanghao".getBytes(),"chenjie".getBytes(),"wangkai".getBytes(),"chenli".getBytes(),"chenmin".getBytes(),"wangxiuzhen".getBytes(),"liyulan".getBytes(),"liuxiuying".getBytes(),"wangping".getBytes(),"wangping".getBytes(),"zhangbo".getBytes(),"liuguiying".getBytes(),"yangxiuying".getBytes(),"zhangying".getBytes(),"yangli".getBytes(),"zhangjian".getBytes(),"lijun4".getBytes(),"lili".getBytes(),"wangbo".getBytes(),"zhanghong".getBytes(),"liudan".getBytes(),"lixin".getBytes(),"wangli".getBytes(),"yangjing".getBytes(),"liuchao".getBytes(),"zhangjuan".getBytes(),"yangfan".getBytes(),"liuyan".getBytes(),"liuying".getBytes(),"lixue".getBytes(),"lixiuzhen".getBytes(),"zhangxin".getBytes(),"wangjian".getBytes(),"liuyulan".getBytes(),"liuhui".getBytes(),"liubo".getBytes(),"zhanghao".getBytes(),"zhangming".getBytes(),"chenyan".getBytes(),"zhangxia".getBytes(),"chenyan".getBytes(),"yangjie".getBytes(),"wangshuai".getBytes(),"lihui".getBytes(),"wangxue".getBytes(),"yangjun".getBytes(),"zhangxu".getBytes(),"liugang".getBytes(),"wanghua".getBytes(),"yangmin".getBytes(),"wangning".getBytes(),"lining".getBytes(),"wangjun".getBytes(),"liuguilan".getBytes(),"liubin".getBytes(),"zhangping".getBytes(),"wangting".getBytes(),"chentao".getBytes(),"wangyumei".getBytes(),"wangna".getBytes(),"zhangbin".getBytes(),"chenlong".getBytes(),"lilin".getBytes(),"wangyuzhen".getBytes(),"zhangfengying".getBytes(),"wanghong".getBytes(),"lifengying".getBytes(),"yangyang".getBytes(),"liting".getBytes(),"zhangjun".getBytes(),"wanglin".getBytes(),"chenying".getBytes(),"chenjun".getBytes(),"liuxia".getBytes(),"chenhao".getBytes(),"zhangkai".getBytes(),"wangjing".getBytes(),"chenfang".getBytes(),"zhangting".getBytes(),"yangtao".getBytes(),"yangbo".getBytes(),"chenhong".getBytes(),"liuhuan".getBytes(),"wangyuying".getBytes(),"chenjuan".getBytes(),"chengang".getBytes(),"wanghui".getBytes(),"zhangying".getBytes(),"zhanglin".getBytes(),"zhangna".getBytes(),"zhangyumei".getBytes(),"wangfengying".getBytes(),"zhangyuying".getBytes(),"lihongmei".getBytes(),"liujia".getBytes(),"liulei".getBytes(),"zhangqian".getBytes(),"liupeng".getBytes(),"wangxu".getBytes(),"zhangxue".getBytes(),"liyang".getBytes(),"zhangxiuzhen".getBytes(),"wangmei".getBytes(),"wangjianhua".getBytes(),"liyumei".getBytes(),"wangying".getBytes(),"liuping".getBytes(),"yangmei".getBytes(),"lifei".getBytes(),"wangliang".getBytes(),"lilei".getBytes(),"lijianhua".getBytes(),"wangyu".getBytes(),"chenling".getBytes(),"zhangjianhua".getBytes(),"liuxin".getBytes(),"wangqian".getBytes(),"zhangshuai".getBytes(),"lijian".getBytes(),"chenlin".getBytes(),"liyang".getBytes(),"chenqiang".getBytes(),"zhaojing".getBytes(),"wangcheng".getBytes(),"zhangyuzhen".getBytes(),"chenchao".getBytes(),"chenliang".getBytes(),"liuna".getBytes(),"wangqin".getBytes(),"zhanglanying".getBytes(),"zhanghui".getBytes(),"liuchang".getBytes(),"liqian".getBytes(),"yangyan".getBytes(),"zhangliang".getBytes(),"zhangjian".getBytes(),"liyun".getBytes(),"zhangqin".getBytes(),"wanglanying".getBytes(),"liyuzhen".getBytes(),"liuping".getBytes(),"chenguiying".getBytes(),"liuying".getBytes(),"yangchao".getBytes(),"zhangmei".getBytes(),"chenping".getBytes(),"wangjian".getBytes(),"liuhong".getBytes(),"zhaowei".getBytes(),"zhangyun".getBytes(),"zhangning".getBytes(),"yanglin".getBytes(),"zhangjie".getBytes(),"gaofeng".getBytes(),"wangjianguo".getBytes(),"yangyang".getBytes(),"chenhua".getBytes(),"yanghua".getBytes(),"wangjianjun".getBytes(),"yangliu".getBytes(),"liuyang".getBytes(),"wangshuzhen".getBytes(),"yangfang".getBytes(),"lichunmei".getBytes(),"liujun".getBytes(),"wanghaiyan".getBytes(),"liuling".getBytes(),"chenchen".getBytes(),"wanghuan".getBytes(),"lidongmei".getBytes(),"zhanglong".getBytes(),"chenbo".getBytes(),"chenlei".getBytes(),"wangyun".getBytes(),"wangfeng".getBytes(),"wangxiurong".getBytes(),"wangrui".getBytes(),"liqin".getBytes(),"liguizhen".getBytes(),"chenpeng".getBytes(),"wangying".getBytes(),"liufei".getBytes(),"wangxiuyun".getBytes(),"chenming".getBytes(),"wangguirong".getBytes(),"lihao".getBytes(),"wangzhiqiang".getBytes(),"zhangdan".getBytes(),"lifeng".getBytes(),"zhanghongmei".getBytes(),"liufengying".getBytes(),"liyuying".getBytes(),"wangxiumei".getBytes(),"lijia".getBytes(),"wanglijuan".getBytes(),"chenhui".getBytes(),"zhangtingting".getBytes(),"zhangfang".getBytes(),"wangtingting".getBytes(),"wangyuhua".getBytes(),"zhangjianguo".getBytes(),"lilanying".getBytes(),"wangguizhen".getBytes(),"lixiumei".getBytes(),"chenyulan".getBytes(),"chenxia".getBytes(),"liukai".getBytes(),"zhangyuhua".getBytes(),"liuyumei".getBytes(),"liuhua".getBytes(),"libing".getBytes(),"zhanglei".getBytes(),"wangdong".getBytes(),"lijianjun".getBytes(),"liuyuzhen".getBytes(),"wanglin".getBytes(),"lijianguo".getBytes(),"liying".getBytes(),"yangwei".getBytes(),"liguirong".getBytes(),"wanglong".getBytes(),"liuting".getBytes(),"chenxiulan".getBytes(),"zhangjianjun".getBytes(),"lixiurong".getBytes(),"liuming".getBytes(),"zhoumin".getBytes(),"zhangxiumei".getBytes(),"lixuemei".getBytes(),"huangwei".getBytes(),"zhanghaiyan".getBytes(),"wangshulan".getBytes(),"lizhiqiang".getBytes(),"yanglei".getBytes(),"lijing".getBytes(),"litingting".getBytes(),"zhangxiurong".getBytes(),"liujianhua".getBytes(),"wanglili".getBytes(),"zhaomin".getBytes(),"chenyun".getBytes(),"lihaiyan".getBytes(),"zhangguirong".getBytes(),"zhangjing".getBytes(),"liuli".getBytes(),"likai".getBytes(),"zhangyu".getBytes(),"zhangfeng".getBytes(),"liuxiulan".getBytes(),"zhangzhiqiang".getBytes(),"lilong".getBytes(),"lixiuyun".getBytes(),"lixiufang".getBytes(),"lishuai".getBytes(),"lixin".getBytes(),"liuyun".getBytes(),"zhanglili".getBytes(),"lijie".getBytes(),"zhangxiuyun".getBytes(),"wangshuying".getBytes(),"wangchunmei".getBytes(),"wanghongmei".getBytes(),"chenbin".getBytes(),"liyuhua".getBytes(),"liguifang".getBytes(),"zhangying".getBytes(),"chenfei".getBytes(),"wangbo".getBytes(),"liuhao".getBytes(),"huangxiuying".getBytes(),"liuyuying".getBytes(),"lishuzhen".getBytes(),"huangyong".getBytes(),"zhouwei".getBytes(),"wangxiufang".getBytes(),"wanglihua".getBytes(),"wangdandan".getBytes(),"libin".getBytes(),"wangguixiang".getBytes(),"wangkun".getBytes(),"liuhui".getBytes(),"lixiang".getBytes(),"zhangrui".getBytes(),"zhangguizhen".getBytes(),"wangshuhua".getBytes(),"liushuai".getBytes(),"zhangfei".getBytes(),"zhangxiufang".getBytes(),"wangyang".getBytes(),"chenjie".getBytes(),"zhangguifang".getBytes(),"zhanglijuan".getBytes(),"wangrong".getBytes(),"wuxiuying".getBytes(),"yangming".getBytes(),"liguixiang".getBytes(),"mali".getBytes(),"liuqian".getBytes(),"yangxiulan".getBytes(),"yangling".getBytes(),"wangxiuhua".getBytes(),"yangping".getBytes(),"wangbin".getBytes(),"liliang".getBytes(),"lirong".getBytes(),"liguizhi".getBytes(),"lilin".getBytes(),"liyan".getBytes(),"lijian".getBytes(),"wangbing".getBytes(),"wangguifang".getBytes(),"wangming".getBytes(),"chenmei".getBytes(),"zhangchunmei".getBytes(),"liyang".getBytes(),"wangyan".getBytes(),"wangdongmei".getBytes(),"liufeng".getBytes(),"lixiuhua".getBytes(),"lidandan".getBytes(),"yangxue".getBytes(),"liuyuhua".getBytes(),"maxiuying".getBytes(),"zhanglihua".getBytes(),"zhangshuzhen".getBytes(),"lixiaohong".getBytes(),"zhangbo".getBytes(),"wangxin".getBytes(),"wangguizhi".getBytes(),"zhaoli".getBytes(),"zhangxiuhua".getBytes(),"zhanglin".getBytes(),"huangmin".getBytes(),"yangjuan".getBytes(),"wangjinfeng".getBytes(),"zhoujie".getBytes(),"wanglei".getBytes(),"chenjianhua".getBytes(),"liumei".getBytes(),"yangguiying".getBytes(),"lishuying".getBytes(),"chenyuying".getBytes(),"yangxiuzhen".getBytes(),"sunxiuying".getBytes(),"zhaojun".getBytes(),"zhaoyong".getBytes(),"liubing".getBytes(),"yangbin".getBytes(),"liwen".getBytes(),"chenlin".getBytes(),"chenping".getBytes(),"sunwei".getBytes(),"zhangli".getBytes(),"chenjun".getBytes(),"zhangnan".getBytes(),"liuguizhen".getBytes(),"liuyu".getBytes(),"liujianjun".getBytes(),"zhangshuying".getBytes(),"lihongxia".getBytes(),"zhaoxiuying".getBytes(),"libo".getBytes(),"wangli".getBytes(),"zhangrong".getBytes(),"zhangfan".getBytes(),"wangjianping".getBytes(),"zhangguizhi".getBytes(),"zhangyu".getBytes(),"zhouyong".getBytes(),"zhangkun".getBytes(),"xuwei".getBytes(),"wangguihua".getBytes(),"liuqin".getBytes(),"zhoujing".getBytes(),"xumin".getBytes(),"liutingting".getBytes(),"xujing".getBytes(),"yanghong".getBytes(),"wanglu".getBytes(),"zhangshulan".getBytes(),"zhangwen".getBytes(),"yangyan".getBytes(),"chenguilan".getBytes(),"zhouli".getBytes(),"lishuhua".getBytes(),"chenxin".getBytes(),"machao".getBytes(),"liujianguo".getBytes(),"liguihua".getBytes(),"wangfenglan".getBytes(),"lishulan".getBytes(),"chenxiuzhen".getBytes()};


    @Override
    public void registerExtenderCallbacks(final IBurpExtenderCallbacks callbacks)
    {

        // obtain our output and error streams
        stdout = new PrintWriter(callbacks.getStdout(), true);

        // write a message to our output stream
        stdout.println("Author:lufei");

        // obtain an extension helpers object
        helpers = callbacks.getHelpers();

        // set our extension name
        callbacks.setExtensionName("Top500PinYinName");

        // register ourselves as an Intruder payload generator
        callbacks.registerIntruderPayloadGeneratorFactory(this);

    }

    //
    // implement IIntruderPayloadGeneratorFactory
    //

    @Override
    public String getGeneratorName()
    {
        return "Top500PinYinName";
    }

    @Override
    public IIntruderPayloadGenerator createNewInstance(IIntruderAttack attack)
    {
        // return a new IIntruderPayloadGenerator to generate payloads for this attack
        return new IntruderPayloadGenerator();
    }


    //
    // class to generate payloads from a simple list
    //

    class IntruderPayloadGenerator implements IIntruderPayloadGenerator
    {
        int payloadIndex;

        @Override
        public boolean hasMorePayloads()
        {
            return payloadIndex < PAYLOADS.length;
        }

        @Override
        public byte[] getNextPayload(byte[] baseValue)
        {
            byte[] payload = PAYLOADS[payloadIndex];
            payloadIndex++;
            return payload;
        }

        @Override
        public void reset()
        {
            payloadIndex = 0;
        }
    }


}