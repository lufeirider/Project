package burp;

import java.io.PrintWriter;

public class BurpExtender implements IBurpExtender, IIntruderPayloadGeneratorFactory
{
    private IExtensionHelpers helpers;
    private PrintWriter stdout;

    // hard-coded payloads
    // [in reality, you would use an extension for something cleverer than this]
     byte[][] PAYLOADS = new byte[][]{"张伟".getBytes(),"王伟".getBytes(),"王芳".getBytes(),"李伟".getBytes(),"李娜".getBytes(),"张敏".getBytes(),"李静".getBytes(),"王静".getBytes(),"刘伟".getBytes(),"张丽".getBytes(),"王丽".getBytes(),"张静".getBytes(),"李强".getBytes(),"王敏".getBytes(),"李敏".getBytes(),"王磊".getBytes(),"刘洋".getBytes(),"王艳".getBytes(),"王勇".getBytes(),"李军".getBytes(),"张勇".getBytes(),"李杰".getBytes(),"张杰".getBytes(),"张磊".getBytes(),"王强".getBytes(),"李娟".getBytes(),"王军".getBytes(),"张艳".getBytes(),"张涛".getBytes(),"王涛".getBytes(),"李艳".getBytes(),"王超".getBytes(),"李明".getBytes(),"李勇".getBytes(),"王娟".getBytes(),"刘杰".getBytes(),"刘敏".getBytes(),"李霞".getBytes(),"李丽".getBytes(),"张军".getBytes(),"王杰".getBytes(),"张强".getBytes(),"王秀兰".getBytes(),"王刚".getBytes(),"王平".getBytes(),"刘芳".getBytes(),"张燕".getBytes(),"刘艳".getBytes(),"刘军".getBytes(),"李平".getBytes(),"王辉".getBytes(),"王燕".getBytes(),"陈静".getBytes(),"刘勇".getBytes(),"李玲".getBytes(),"李桂英".getBytes(),"王丹".getBytes(),"李刚".getBytes(),"李丹".getBytes(),"李萍".getBytes(),"王鹏".getBytes(),"刘涛".getBytes(),"陈伟".getBytes(),"张华".getBytes(),"刘静".getBytes(),"李涛".getBytes(),"王桂英".getBytes(),"张秀兰".getBytes(),"李红".getBytes(),"李超".getBytes(),"刘丽".getBytes(),"张桂英".getBytes(),"王玉兰".getBytes(),"李燕".getBytes(),"张鹏".getBytes(),"李秀兰".getBytes(),"张超".getBytes(),"王玲".getBytes(),"张玲".getBytes(),"李华".getBytes(),"王飞".getBytes(),"张玉兰".getBytes(),"王桂兰".getBytes(),"王英".getBytes(),"刘强".getBytes(),"陈秀英".getBytes(),"李英".getBytes(),"李辉".getBytes(),"李梅".getBytes(),"陈勇".getBytes(),"王鑫".getBytes(),"李芳".getBytes(),"张桂兰".getBytes(),"李波".getBytes(),"杨勇".getBytes(),"王霞".getBytes(),"李桂兰".getBytes(),"王斌".getBytes(),"李鹏".getBytes(),"张平".getBytes(),"张莉".getBytes(),"张辉".getBytes(),"张宇".getBytes(),"刘娟".getBytes(),"李斌".getBytes(),"王浩".getBytes(),"陈杰".getBytes(),"王凯".getBytes(),"陈丽".getBytes(),"陈敏".getBytes(),"王秀珍".getBytes(),"李玉兰".getBytes(),"刘秀英".getBytes(),"王萍".getBytes(),"王萍".getBytes(),"张波".getBytes(),"刘桂英".getBytes(),"杨秀英".getBytes(),"张英".getBytes(),"杨丽".getBytes(),"张健".getBytes(),"李俊".getBytes(),"李莉".getBytes(),"王波".getBytes(),"张红".getBytes(),"刘丹".getBytes(),"李鑫".getBytes(),"王莉".getBytes(),"杨静".getBytes(),"刘超".getBytes(),"张娟".getBytes(),"杨帆".getBytes(),"刘燕".getBytes(),"刘英".getBytes(),"李雪".getBytes(),"李秀珍".getBytes(),"张鑫".getBytes(),"王健".getBytes(),"刘玉兰".getBytes(),"刘辉".getBytes(),"刘波".getBytes(),"张浩".getBytes(),"张明".getBytes(),"陈燕".getBytes(),"张霞".getBytes(),"陈艳".getBytes(),"杨杰".getBytes(),"王帅".getBytes(),"李慧".getBytes(),"王雪".getBytes(),"杨军".getBytes(),"张旭".getBytes(),"刘刚".getBytes(),"王华".getBytes(),"杨敏".getBytes(),"王宁".getBytes(),"李宁".getBytes(),"王俊".getBytes(),"刘桂兰".getBytes(),"刘斌".getBytes(),"张萍".getBytes(),"王婷".getBytes(),"陈涛".getBytes(),"王玉梅".getBytes(),"王娜".getBytes(),"张斌".getBytes(),"陈龙".getBytes(),"李林".getBytes(),"王玉珍".getBytes(),"张凤英".getBytes(),"王红".getBytes(),"李凤英".getBytes(),"杨洋".getBytes(),"李婷".getBytes(),"张俊".getBytes(),"王林".getBytes(),"陈英".getBytes(),"陈军".getBytes(),"刘霞".getBytes(),"陈浩".getBytes(),"张凯".getBytes(),"王晶".getBytes(),"陈芳".getBytes(),"张婷".getBytes(),"杨涛".getBytes(),"杨波".getBytes(),"陈红".getBytes(),"刘欢".getBytes(),"王玉英".getBytes(),"陈娟".getBytes(),"陈刚".getBytes(),"王慧".getBytes(),"张颖".getBytes(),"张林".getBytes(),"张娜".getBytes(),"张玉梅".getBytes(),"王凤英".getBytes(),"张玉英".getBytes(),"李红梅".getBytes(),"刘佳".getBytes(),"刘磊".getBytes(),"张倩".getBytes(),"刘鹏".getBytes(),"王旭".getBytes(),"张雪".getBytes(),"李阳".getBytes(),"张秀珍".getBytes(),"王梅".getBytes(),"王建华".getBytes(),"李玉梅".getBytes(),"王颖".getBytes(),"刘平".getBytes(),"杨梅".getBytes(),"李飞".getBytes(),"王亮".getBytes(),"李磊".getBytes(),"李建华".getBytes(),"王宇".getBytes(),"陈玲".getBytes(),"张建华".getBytes(),"刘鑫".getBytes(),"王倩".getBytes(),"张帅".getBytes(),"李健".getBytes(),"陈林".getBytes(),"李洋".getBytes(),"陈强".getBytes(),"赵静".getBytes(),"王成".getBytes(),"张玉珍".getBytes(),"陈超".getBytes(),"陈亮".getBytes(),"刘娜".getBytes(),"王琴".getBytes(),"张兰英".getBytes(),"张慧".getBytes(),"刘畅".getBytes(),"李倩".getBytes(),"杨艳".getBytes(),"张亮".getBytes(),"张建".getBytes(),"李云".getBytes(),"张琴".getBytes(),"王兰英".getBytes(),"李玉珍".getBytes(),"刘萍".getBytes(),"陈桂英".getBytes(),"刘颖".getBytes(),"杨超".getBytes(),"张梅".getBytes(),"陈平".getBytes(),"王建".getBytes(),"刘红".getBytes(),"赵伟".getBytes(),"张云".getBytes(),"张宁".getBytes(),"杨林".getBytes(),"张洁".getBytes(),"高峰".getBytes(),"王建国".getBytes(),"杨阳".getBytes(),"陈华".getBytes(),"杨华".getBytes(),"王建军".getBytes(),"杨柳".getBytes(),"刘阳".getBytes(),"王淑珍".getBytes(),"杨芳".getBytes(),"李春梅".getBytes(),"刘俊".getBytes(),"王海燕".getBytes(),"刘玲".getBytes(),"陈晨".getBytes(),"王欢".getBytes(),"李冬梅".getBytes(),"张龙".getBytes(),"陈波".getBytes(),"陈磊".getBytes(),"王云".getBytes(),"王峰".getBytes(),"王秀荣".getBytes(),"王瑞".getBytes(),"李琴".getBytes(),"李桂珍".getBytes(),"陈鹏".getBytes(),"王莹".getBytes(),"刘飞".getBytes(),"王秀云".getBytes(),"陈明".getBytes(),"王桂荣".getBytes(),"李浩".getBytes(),"王志强".getBytes(),"张丹".getBytes(),"李峰".getBytes(),"张红梅".getBytes(),"刘凤英".getBytes(),"李玉英".getBytes(),"王秀梅".getBytes(),"李佳".getBytes(),"王丽娟".getBytes(),"陈辉".getBytes(),"张婷婷".getBytes(),"张芳".getBytes(),"王婷婷".getBytes(),"王玉华".getBytes(),"张建国".getBytes(),"李兰英".getBytes(),"王桂珍".getBytes(),"李秀梅".getBytes(),"陈玉兰".getBytes(),"陈霞".getBytes(),"刘凯".getBytes(),"张玉华".getBytes(),"刘玉梅".getBytes(),"刘华".getBytes(),"李兵".getBytes(),"张雷".getBytes(),"王东".getBytes(),"李建军".getBytes(),"刘玉珍".getBytes(),"王琳".getBytes(),"李建国".getBytes(),"李颖".getBytes(),"杨伟".getBytes(),"李桂荣".getBytes(),"王龙".getBytes(),"刘婷".getBytes(),"陈秀兰".getBytes(),"张建军".getBytes(),"李秀荣".getBytes(),"刘明".getBytes(),"周敏".getBytes(),"张秀梅".getBytes(),"李雪梅".getBytes(),"黄伟".getBytes(),"张海燕".getBytes(),"王淑兰".getBytes(),"李志强".getBytes(),"杨磊".getBytes(),"李晶".getBytes(),"李婷婷".getBytes(),"张秀荣".getBytes(),"刘建华".getBytes(),"王丽丽".getBytes(),"赵敏".getBytes(),"陈云".getBytes(),"李海燕".getBytes(),"张桂荣".getBytes(),"张晶".getBytes(),"刘莉".getBytes(),"李凯".getBytes(),"张玉".getBytes(),"张峰".getBytes(),"刘秀兰".getBytes(),"张志强".getBytes(),"李龙".getBytes(),"李秀云".getBytes(),"李秀芳".getBytes(),"李帅".getBytes(),"李欣".getBytes(),"刘云".getBytes(),"张丽丽".getBytes(),"李洁".getBytes(),"张秀云".getBytes(),"王淑英".getBytes(),"王春梅".getBytes(),"王红梅".getBytes(),"陈斌".getBytes(),"李玉华".getBytes(),"李桂芳".getBytes(),"张莹".getBytes(),"陈飞".getBytes(),"王博".getBytes(),"刘浩".getBytes(),"黄秀英".getBytes(),"刘玉英".getBytes(),"李淑珍".getBytes(),"黄勇".getBytes(),"周伟".getBytes(),"王秀芳".getBytes(),"王丽华".getBytes(),"王丹丹".getBytes(),"李彬".getBytes(),"王桂香".getBytes(),"王坤".getBytes(),"刘慧".getBytes(),"李想".getBytes(),"张瑞".getBytes(),"张桂珍".getBytes(),"王淑华".getBytes(),"刘帅".getBytes(),"张飞".getBytes(),"张秀芳".getBytes(),"王洋".getBytes(),"陈洁".getBytes(),"张桂芳".getBytes(),"张丽娟".getBytes(),"王荣".getBytes(),"吴秀英".getBytes(),"杨明".getBytes(),"李桂香".getBytes(),"马丽".getBytes(),"刘倩".getBytes(),"杨秀兰".getBytes(),"杨玲".getBytes(),"王秀华".getBytes(),"杨平".getBytes(),"王彬".getBytes(),"李亮".getBytes(),"李荣".getBytes(),"李桂芝".getBytes(),"李琳".getBytes(),"李岩".getBytes(),"李建".getBytes(),"王兵".getBytes(),"王桂芳".getBytes(),"王明".getBytes(),"陈梅".getBytes(),"张春梅".getBytes(),"李杨".getBytes(),"王岩".getBytes(),"王冬梅".getBytes(),"刘峰".getBytes(),"李秀华".getBytes(),"李丹丹".getBytes(),"杨雪".getBytes(),"刘玉华".getBytes(),"马秀英".getBytes(),"张丽华".getBytes(),"张淑珍".getBytes(),"李小红".getBytes(),"张博".getBytes(),"王欣".getBytes(),"王桂芝".getBytes(),"赵丽".getBytes(),"张秀华".getBytes(),"张琳".getBytes(),"黄敏".getBytes(),"杨娟".getBytes(),"王金凤".getBytes(),"周杰".getBytes(),"王雷".getBytes(),"陈建华".getBytes(),"刘梅".getBytes(),"杨桂英".getBytes(),"李淑英".getBytes(),"陈玉英".getBytes(),"杨秀珍".getBytes(),"孙秀英".getBytes(),"赵军".getBytes(),"赵勇".getBytes(),"刘兵".getBytes(),"杨斌".getBytes(),"李文".getBytes(),"陈琳".getBytes(),"陈萍".getBytes(),"孙伟".getBytes(),"张利".getBytes(),"陈俊".getBytes(),"张楠".getBytes(),"刘桂珍".getBytes(),"刘宇".getBytes(),"刘建军".getBytes(),"张淑英".getBytes(),"李红霞".getBytes(),"赵秀英".getBytes(),"李博".getBytes(),"王利".getBytes(),"张荣".getBytes(),"张帆".getBytes(),"王建平".getBytes(),"张桂芝".getBytes(),"张瑜".getBytes(),"周勇".getBytes(),"张坤".getBytes(),"徐伟".getBytes(),"王桂花".getBytes(),"刘琴".getBytes(),"周静".getBytes(),"徐敏".getBytes(),"刘婷婷".getBytes(),"徐静".getBytes(),"杨红".getBytes(),"王璐".getBytes(),"张淑兰".getBytes(),"张文".getBytes(),"杨燕".getBytes(),"陈桂兰".getBytes(),"周丽".getBytes(),"李淑华".getBytes(),"陈鑫".getBytes(),"马超".getBytes(),"刘建国".getBytes(),"李桂花".getBytes(),"王凤兰".getBytes(),"李淑兰".getBytes(),"陈秀珍".getBytes()};


    @Override
    public void registerExtenderCallbacks(final IBurpExtenderCallbacks callbacks)
    {

        // obtain our output and error streams
        stdout = new PrintWriter(callbacks.getStdout(), true);

        // write a message to our output stream
        stdout.println("Author:lufei");

        // obtain an extension helpers object
        helpers = callbacks.getHelpers();

        // set our extension name
        callbacks.setExtensionName("Top500ChineseName");

        // register ourselves as an Intruder payload generator
        callbacks.registerIntruderPayloadGeneratorFactory(this);

    }

    //
    // implement IIntruderPayloadGeneratorFactory
    //

    @Override
    public String getGeneratorName()
    {
        return "Top500ChineseName";
    }

    @Override
    public IIntruderPayloadGenerator createNewInstance(IIntruderAttack attack)
    {
        // return a new IIntruderPayloadGenerator to generate payloads for this attack
        return new IntruderPayloadGenerator();
    }


    //
    // class to generate payloads from a simple list
    //

    class IntruderPayloadGenerator implements IIntruderPayloadGenerator
    {
        int payloadIndex;

        @Override
        public boolean hasMorePayloads()
        {
            return payloadIndex < PAYLOADS.length;
        }

        @Override
        public byte[] getNextPayload(byte[] baseValue)
        {
            byte[] payload = PAYLOADS[payloadIndex];
            payloadIndex++;
            return payload;
        }

        @Override
        public void reset()
        {
            payloadIndex = 0;
        }
    }


}