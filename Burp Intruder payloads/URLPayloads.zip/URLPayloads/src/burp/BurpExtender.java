package burp;

import java.io.PrintWriter;

public class BurpExtender implements IBurpExtender, IIntruderPayloadGeneratorFactory
{
    private IExtensionHelpers helpers;
    private PrintWriter stdout;

    // hard-coded payloads
    // [in reality, you would use an extension for something cleverer than this]
     byte[][] PAYLOADS = new byte[256][];


    @Override
    public void registerExtenderCallbacks(final IBurpExtenderCallbacks callbacks)
    {

        for(int i=0;i<256;i++)
        {
            PAYLOADS[i] = String.format("%02x",i).getBytes();
        }

        // obtain our output and error streams
        stdout = new PrintWriter(callbacks.getStdout(), true);

        // write a message to our output stream
        stdout.println("Author:lufei");

        // obtain an extension helpers object
        helpers = callbacks.getHelpers();

        // set our extension name
        callbacks.setExtensionName("URLPayloads");

        // register ourselves as an Intruder payload generator
        callbacks.registerIntruderPayloadGeneratorFactory(this);

    }

    //
    // implement IIntruderPayloadGeneratorFactory
    //

    @Override
    public String getGeneratorName()
    {
        return "URLPayloads";
    }

    @Override
    public IIntruderPayloadGenerator createNewInstance(IIntruderAttack attack)
    {
        // return a new IIntruderPayloadGenerator to generate payloads for this attack
        return new IntruderPayloadGenerator();
    }


    //
    // class to generate payloads from a simple list
    //

    class IntruderPayloadGenerator implements IIntruderPayloadGenerator
    {
        int payloadIndex;

        @Override
        public boolean hasMorePayloads()
        {
            return payloadIndex < PAYLOADS.length;
        }

        @Override
        public byte[] getNextPayload(byte[] baseValue)
        {
            byte[] payload = PAYLOADS[payloadIndex];
            payloadIndex++;
            return payload;
        }

        @Override
        public void reset()
        {
            payloadIndex = 0;
        }
    }


}